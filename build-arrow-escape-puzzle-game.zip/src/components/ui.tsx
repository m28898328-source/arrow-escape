import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import type { ScoreEntry } from '../game/storage';

const INK = '#221C35';
export const DIR_COLORS = ['#F2553D', '#2E6BE6', '#14B87F', '#F9B208'] as const;

export const fmt = (n: number) => Math.round(n).toLocaleString('en-US');

/* ------------------------------------------------------------------ */
/* Icons                                                               */
/* ------------------------------------------------------------------ */

export type IconName =
  | 'pause'
  | 'play'
  | 'soundOn'
  | 'soundOff'
  | 'bulb'
  | 'trophy'
  | 'home'
  | 'restart'
  | 'next'
  | 'close'
  | 'snow'
  | 'bomb'
  | 'bumper'
  | 'tap';

const ICONS: Record<IconName, ReactNode> = {
  pause: (
    <>
      <rect x="5" y="4" width="5" height="16" rx="1.6" fill="currentColor" stroke="none" />
      <rect x="14" y="4" width="5" height="16" rx="1.6" fill="currentColor" stroke="none" />
    </>
  ),
  play: <path d="M7 4.6v14.8a1 1 0 0 0 1.5.86l12.3-7.4a1 1 0 0 0 0-1.72L8.5 3.74A1 1 0 0 0 7 4.6z" fill="currentColor" stroke="none" />,
  soundOn: (
    <>
      <path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4H4z" fill="currentColor" />
      <path d="M15.6 9a4.2 4.2 0 0 1 0 6M18.2 6.4a7.8 7.8 0 0 1 0 11.2" />
    </>
  ),
  soundOff: (
    <>
      <path d="M4 9.5v5h3.5l4.5 4v-13l-4.5 4H4z" fill="currentColor" />
      <path d="M16 9.5l5 5M21 9.5l-5 5" />
    </>
  ),
  bulb: (
    <>
      <path d="M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V17h5.2v-1.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z" />
      <path d="M10 20.5h4" />
    </>
  ),
  trophy: (
    <>
      <path d="M7 4h10v5a5 5 0 0 1-10 0V4z" />
      <path d="M7 6H4v1.3A3.7 3.7 0 0 0 7.6 11M17 6h3v1.3a3.7 3.7 0 0 1-3.6 3.7M12 14v4M8 20h8" />
    </>
  ),
  home: (
    <>
      <path d="M3.5 11.5L12 4l8.5 7.5" />
      <path d="M6 10v9.5h12V10" />
    </>
  ),
  restart: (
    <>
      <path d="M4.6 12a7.4 7.4 0 1 0 2.3-5.4" />
      <path d="M4 4.4V9h4.6" />
    </>
  ),
  next: <path d="M4.5 12h13.5M12.5 6l6 6-6 6" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  snow: <path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9" />,
  bomb: (
    <>
      <circle cx="10.5" cy="14" r="6.5" fill="currentColor" />
      <path d="M15 9.5L17.5 7M17.5 7c.4-1.6 1.4-2.6 3-3" />
    </>
  ),
  bumper: <path d="M6.5 17.5l11-11" strokeWidth="5.5" />,
  tap: (
    <>
      <circle cx="12" cy="12" r="3.2" fill="currentColor" />
      <path d="M12 3.2v2.6M12 18.2v2.6M3.2 12h2.6M18.2 12h2.6M5.8 5.8l1.8 1.8M16.4 16.4l1.8 1.8M18.2 5.8l-1.8 1.8M7.6 16.4l-1.8 1.8" />
    </>
  ),
};

export function Icon({ name, size = 22, className }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={2.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
    >
      {ICONS[name]}
    </svg>
  );
}

const HEART_PATH =
  'M12 20.6l-1.3-1.2C5.5 14.7 2.2 11.7 2.2 8A5.1 5.1 0 0 1 7.4 2.9c1.7 0 3.2.8 4.2 2 .2.3.6.3.8 0 1-1.2 2.5-2 4.2-2A5.1 5.1 0 0 1 21.8 8c0 3.7-3.3 6.7-8.5 11.4L12 20.6z';

export function Heart({ filled = true, size = 24, className }: { filled?: boolean; size?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" className={className}>
      <path d={HEART_PATH} fill={filled ? '#F0435E' : '#E9DEC5'} stroke={INK} strokeWidth={2.2} strokeLinejoin="round" />
      {filled && <path d="M6.6 7.4c.4-1.1 1.3-1.7 2.3-1.6" fill="none" stroke="#FFB3BF" strokeWidth={1.8} strokeLinecap="round" />}
    </svg>
  );
}

const STAR_PATH = 'M12 2.6l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9L12 2.6z';

export function Star({ filled, size = 44, style, className }: { filled: boolean; size?: number; style?: CSSProperties; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true" style={style} className={className}>
      <path d={STAR_PATH} fill={filled ? '#F9B208' : '#E9DEC5'} stroke={INK} strokeWidth={2} strokeLinejoin="round" />
    </svg>
  );
}

/** A little arrow drawn the same way the board draws them. dir: 0 up, 1 right, 2 down, 3 left. */
export function MiniArrow({
  dir,
  size = 30,
  color,
  long = false,
  className,
}: {
  dir: 0 | 1 | 2 | 3;
  size?: number;
  color?: string;
  long?: boolean;
  className?: string;
}) {
  const fill = color ?? DIR_COLORS[dir];
  const w = long ? 64 : 40;
  const tail = 9;
  const neck = w - 18;
  const tip = w - 5;
  return (
    <svg
      viewBox={`0 0 ${w} 40`}
      width={(size * w) / 40}
      height={size}
      aria-hidden="true"
      className={className}
      style={{ transform: `rotate(${dir * 90 - 90}deg)` }}
    >
      <g strokeLinecap="round" strokeLinejoin="round">
        <path d={`M${tail} 20H${neck}`} stroke={INK} strokeWidth={15} fill="none" />
        <path d={`M${neck - 2} 8L${tip} 20L${neck - 2} 32Z`} stroke={INK} strokeWidth={7} fill={INK} />
        <path d={`M${tail} 20H${neck}`} stroke={fill} strokeWidth={10} fill="none" />
        <path d={`M${neck - 2} 8L${tip} 20L${neck - 2} 32Z`} stroke={fill} strokeWidth={2} fill={fill} />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Animated number                                                     */
/* ------------------------------------------------------------------ */

export function useCountUp(value: number, ms = 420, start?: number): number {
  const [shown, setShown] = useState(start ?? value);
  const shownRef = useRef(start ?? value);
  useEffect(() => {
    const from = shownRef.current;
    if (from === value) return;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const k = Math.min(1, (now - t0) / ms);
      const v = Math.round(from + (value - from) * (1 - Math.pow(1 - k, 3)));
      shownRef.current = v;
      setShown(v);
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, ms]);
  return shown;
}

/* ------------------------------------------------------------------ */
/* High-score table                                                    */
/* ------------------------------------------------------------------ */

export function ScoreTable({ scores, highlightId, maxHeight }: { scores: ScoreEntry[]; highlightId?: string; maxHeight?: number }) {
  const activeRef = useRef<HTMLLIElement>(null);
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: 'nearest' });
  }, [highlightId]);

  if (!scores.length) {
    return (
      <div className="rounded-2xl border-[2.5px] border-dashed border-line px-4 py-6 text-center text-sm font-medium text-ink-soft">
        No scores yet. Finish a run to claim the top spot.
      </div>
    );
  }
  return (
    <div className="overflow-hidden rounded-2xl border-[2.5px] border-ink bg-white">
      <div className="grid grid-cols-[2.2rem_1fr_3rem_5rem] items-center gap-1 border-b-[2.5px] border-ink bg-socket px-3 py-1.5">
        <span className="label">#</span>
        <span className="label">Name</span>
        <span className="label text-right">Lvl</span>
        <span className="label text-right">Score</span>
      </div>
      <ol className="scroll-thin overflow-y-auto" style={{ maxHeight }}>
        {scores.map((s, i) => {
          const active = s.id === highlightId;
          return (
            <li
              key={s.id}
              ref={active ? activeRef : undefined}
              className={`grid grid-cols-[2.2rem_1fr_3rem_5rem] items-center gap-1 px-3 py-1.5 text-[15px] ${
                active ? 'bg-arrow-left font-semibold' : i % 2 ? 'bg-card' : 'bg-white'
              }`}
            >
              <span className="font-display text-base leading-none">{i + 1}</span>
              <span className="truncate font-medium">{s.name}</span>
              <span className="text-right tabular-nums text-ink-soft">{s.level}</span>
              <span className="text-right font-display text-base leading-none tabular-nums">{fmt(s.score)}</span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
