/**
 * Arrow Escape — puzzle logic.
 *
 * Arrows are snakes on a grid (cells ordered tail → head). Launching one sends
 * its head straight ahead; bumpers deflect it 90°. It escapes if it reaches the
 * edge without touching another arrow.
 *
 * Solvability is guaranteed by construction. "A sits on B's exit path" means
 * "A must leave before B"; the generator only ever adds an arrow (or grows a
 * tail) when that relation stays acyclic, so a valid clearing order always
 * exists and — because removing arrows only ever opens paths — the player can
 * never paint themselves into a corner.
 */

export type Dir = 0 | 1 | 2 | 3; // up, right, down, left
export const DX: readonly number[] = [0, 1, 0, -1];
export const DY: readonly number[] = [-1, 0, 1, 0];
export const OPP: readonly Dir[] = [2, 3, 0, 1];

/** Bumper kinds: 1 = "/", 2 = "\". */
const DEFLECT: readonly (readonly Dir[])[] = [
  [0, 1, 2, 3],
  [1, 0, 3, 2],
  [3, 2, 1, 0],
];

export interface Cell {
  x: number;
  y: number;
}

export interface ArrowDef {
  id: number;
  /** Tail → head. */
  cells: Cell[];
  dir: Dir;
  /** Escapes needed before this arrow thaws (0 = not frozen). */
  frost: number;
  /** Moves left before this arrow blows up (0 = not a bomb). */
  fuse: number;
  /** Position in one known-good clearing order. */
  rank: number;
}

export interface LevelParams {
  cols: number;
  rows: number;
  /** Fraction of the board to cover before gap-filling. */
  fill: number;
  minLen: number;
  maxLen: number;
  /** Chance for a body segment to turn. */
  bend: number;
  bumpers: number;
  frozen: number;
  bombs: number;
  /** Spare moves on a bomb fuse. */
  slack: number;
  /** Reward for locking an arrow that was still free. */
  lockW: number;
  /** Reward for piling onto an arrow that is already locked. */
  pileW: number;
  /** Reward for placing an arrow that starts out locked itself. */
  buryW: number;
  /** Penalty for rim arrows pointing straight out (always free). */
  edgePen: number;
  /** Chance to refuse a "freebie" (rim arrow that locks nothing). */
  noFree: number;
}

export interface LevelDef {
  level: number;
  cols: number;
  rows: number;
  arrows: ArrowDef[];
  bumpers: Uint8Array;
}

export interface Trace {
  /** Free in-board cells travelled after the head. */
  path: Cell[];
  /** Indices into `path` that hold a bumper. */
  turns: number[];
  /** Arrow id that stops the move, -1 if it escapes, -2 if it loops. */
  blockedBy: number;
  /** Heading when the trace ended. */
  exitDir: Dir;
}

export function tracePath(
  cols: number,
  rows: number,
  occ: Int16Array,
  bumpers: Uint8Array,
  head: Cell,
  dir: Dir,
): Trace {
  const path: Cell[] = [];
  const turns: number[] = [];
  let x = head.x;
  let y = head.y;
  let d: Dir = dir;
  const limit = cols * rows * 4 + 8;
  for (let i = 0; i < limit; i++) {
    x += DX[d];
    y += DY[d];
    if (x < 0 || y < 0 || x >= cols || y >= rows) {
      return { path, turns, blockedBy: -1, exitDir: d };
    }
    const idx = y * cols + x;
    const o = occ[idx];
    if (o !== -1) return { path, turns, blockedBy: o, exitDir: d };
    path.push({ x, y });
    const b = bumpers[idx];
    if (b) {
      d = DEFLECT[b][d];
      turns.push(path.length - 1);
    }
  }
  return { path, turns, blockedBy: -2, exitDir: d };
}

/** Cell indices an arrow would sweep if the board were empty. */
export function geometricRay(
  cols: number,
  rows: number,
  bumpers: Uint8Array,
  head: Cell,
  dir: Dir,
): number[] {
  const empty = new Int16Array(cols * rows).fill(-1);
  return tracePath(cols, rows, empty, bumpers, head, dir).path.map((c) => c.y * cols + c.x);
}

/* ------------------------------------------------------------------ */
/* Difficulty curve                                                    */
/* ------------------------------------------------------------------ */

const TABLE: LevelParams[] = [
  { cols: 4, rows: 4, fill: 0.72, minLen: 1, maxLen: 2, bend: 0, bumpers: 0, frozen: 0, bombs: 0, slack: 3, lockW: 0.6, pileW: 0.1, buryW: -0.8, edgePen: -0.15, noFree: 0 },
  { cols: 5, rows: 5, fill: 0.8, minLen: 1, maxLen: 3, bend: 0.25, bumpers: 0, frozen: 0, bombs: 0, slack: 3, lockW: 0.8, pileW: 0.2, buryW: -0.8, edgePen: 0, noFree: 0.1 },
  { cols: 5, rows: 6, fill: 0.84, minLen: 2, maxLen: 3, bend: 0.35, bumpers: 0, frozen: 0, bombs: 0, slack: 3, lockW: 1, pileW: 0.3, buryW: -1, edgePen: 0.15, noFree: 0.2 },
  { cols: 6, rows: 6, fill: 0.84, minLen: 2, maxLen: 4, bend: 0.35, bumpers: 2, frozen: 0, bombs: 0, slack: 3, lockW: 1, pileW: 0.3, buryW: -1, edgePen: 0.2, noFree: 0.2 },
  { cols: 6, rows: 7, fill: 0.86, minLen: 2, maxLen: 4, bend: 0.4, bumpers: 2, frozen: 0, bombs: 0, slack: 3, lockW: 1.2, pileW: 0.4, buryW: -1, edgePen: 0.35, noFree: 0.3 },
  { cols: 6, rows: 7, fill: 0.86, minLen: 2, maxLen: 4, bend: 0.45, bumpers: 2, frozen: 2, bombs: 0, slack: 3, lockW: 1.2, pileW: 0.4, buryW: -1, edgePen: 0.35, noFree: 0.3 },
  { cols: 7, rows: 7, fill: 0.88, minLen: 2, maxLen: 4, bend: 0.45, bumpers: 3, frozen: 2, bombs: 0, slack: 3, lockW: 1.3, pileW: 0.5, buryW: -1, edgePen: 0.5, noFree: 0.3 },
  { cols: 7, rows: 8, fill: 0.88, minLen: 2, maxLen: 4, bend: 0.5, bumpers: 3, frozen: 1, bombs: 1, slack: 3, lockW: 1.3, pileW: 0.5, buryW: -1, edgePen: 0.5, noFree: 0.3 },
  { cols: 7, rows: 8, fill: 0.9, minLen: 2, maxLen: 4, bend: 0.5, bumpers: 3, frozen: 2, bombs: 1, slack: 3, lockW: 1.4, pileW: 0.5, buryW: -1, edgePen: 0.65, noFree: 0.3 },
  { cols: 7, rows: 9, fill: 0.9, minLen: 2, maxLen: 5, bend: 0.5, bumpers: 4, frozen: 2, bombs: 1, slack: 2, lockW: 1.4, pileW: 0.5, buryW: -1, edgePen: 0.7, noFree: 0.3 },
  { cols: 7, rows: 9, fill: 0.9, minLen: 2, maxLen: 5, bend: 0.55, bumpers: 4, frozen: 3, bombs: 2, slack: 2, lockW: 1.5, pileW: 0.6, buryW: -1, edgePen: 0.8, noFree: 0.3 },
  { cols: 8, rows: 9, fill: 0.9, minLen: 2, maxLen: 5, bend: 0.55, bumpers: 4, frozen: 3, bombs: 2, slack: 2, lockW: 1.5, pileW: 0.6, buryW: -1, edgePen: 0.85, noFree: 0.3 },
  { cols: 8, rows: 10, fill: 0.92, minLen: 2, maxLen: 5, bend: 0.55, bumpers: 5, frozen: 3, bombs: 2, slack: 2, lockW: 1.6, pileW: 0.6, buryW: -1, edgePen: 0.9, noFree: 0.3 },
];

export function paramsFor(level: number): LevelParams {
  const p = { ...TABLE[Math.min(level, TABLE.length) - 1] };
  const extra = level - TABLE.length;
  if (extra > 0) {
    p.lockW += Math.min(1, extra * 0.1);
    p.buryW += Math.min(0.8, extra * 0.08);
    p.edgePen += Math.min(0.6, extra * 0.05);
    p.bumpers = Math.min(8, p.bumpers + Math.floor(extra / 3));
    p.frozen = Math.min(6, p.frozen + Math.floor(extra / 3));
    p.bombs = Math.min(3, p.bombs + Math.floor(extra / 4));
    p.slack = extra >= 6 ? 1 : 2;
  }
  return p;
}

/** Which mechanic (if any) appears for the first time on this level. */
export const BUMPER_LEVEL = 4;
export const FROST_LEVEL = 6;
export const BOMB_LEVEL = 8;

/* ------------------------------------------------------------------ */
/* Solver (shared by hints and generator verification)                 */
/* ------------------------------------------------------------------ */

export interface SolverArrow {
  id: number;
  ray: number[];
  frost: number;
  fuse: number;
  rank: number;
}

/**
 * Picks a safe next move: digs toward the most urgent bomb first, otherwise
 * follows the known-good order (lowest rank first), which can never dead-end.
 */
export function suggestMove(occ: Int16Array, arrows: SolverArrow[]): number {
  const byId = new Map<number, SolverArrow>();
  for (const a of arrows) byId.set(a.id, a);

  const blockersOf = (a: SolverArrow): number[] => {
    const out: number[] = [];
    for (const c of a.ray) {
      const o = occ[c];
      if (o >= 0 && o !== a.id && out.indexOf(o) === -1) out.push(o);
    }
    return out;
  };
  const isFree = (a: SolverArrow) => a.frost === 0 && blockersOf(a).length === 0;

  const bombs = arrows.filter((a) => a.fuse > 0).sort((a, b) => a.fuse - b.fuse);
  for (const b of bombs) {
    if (isFree(b)) return b.id;
    const seen = new Set<number>();
    const stack = blockersOf(b);
    while (stack.length) {
      const j = stack.pop() as number;
      if (seen.has(j)) continue;
      seen.add(j);
      const aj = byId.get(j);
      if (!aj) continue;
      if (isFree(aj)) return j;
      for (const k of blockersOf(aj)) stack.push(k);
    }
  }

  let best: SolverArrow | null = null;
  for (const a of arrows) if ((!best || a.rank < best.rank) && isFree(a)) best = a;
  return best ? best.id : -1;
}

/** Plays the level with `suggestMove`; true if it clears without a bomb going off. */
export function verifyLevel(def: LevelDef): boolean {
  const { cols, rows } = def;
  const occ = new Int16Array(cols * rows).fill(-1);
  let live: SolverArrow[] = def.arrows.map((a) => {
    for (const c of a.cells) occ[c.y * cols + c.x] = a.id;
    const head = a.cells[a.cells.length - 1];
    return { id: a.id, ray: geometricRay(cols, rows, def.bumpers, head, a.dir), frost: a.frost, fuse: a.fuse, rank: a.rank };
  });
  const cellsOf = new Map<number, Cell[]>();
  for (const a of def.arrows) cellsOf.set(a.id, a.cells);

  while (live.length) {
    const id = suggestMove(occ, live);
    if (id < 0) return false;
    for (const c of cellsOf.get(id) as Cell[]) occ[c.y * cols + c.x] = -1;
    live = live.filter((a) => a.id !== id);
    for (const a of live) {
      if (a.frost > 0) a.frost--;
      if (a.fuse > 0) {
        a.fuse--;
        if (a.fuse === 0) return false;
      }
    }
  }
  return true;
}

/* ------------------------------------------------------------------ */
/* Generator                                                           */
/* ------------------------------------------------------------------ */

interface GenArrow {
  cells: Cell[];
  dir: Dir;
  ray: number[];
}

function shuffle<T>(arr: T[], rand: () => number): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const t = arr[i];
    arr[i] = arr[j];
    arr[j] = t;
  }
  return arr;
}

function countFree(def: LevelDef): number {
  const { cols, rows } = def;
  const occ = new Int16Array(cols * rows).fill(-1);
  for (const a of def.arrows) for (const c of a.cells) occ[c.y * cols + c.x] = a.id;
  let free = 0;
  for (const a of def.arrows) {
    if (a.frost > 0) continue;
    const head = a.cells[a.cells.length - 1];
    if (tracePath(cols, rows, occ, def.bumpers, head, a.dir).blockedBy === -1) free++;
  }
  return free;
}

function build(level: number, p: LevelParams, rand: () => number): LevelDef {
  const { cols, rows } = p;
  const n = cols * rows;
  const occ = new Int16Array(n).fill(-1);
  const empty = new Int16Array(n).fill(-1);
  const bumpers = new Uint8Array(n);

  // Bumpers live in the interior and never touch each other.
  let nb = 0;
  for (let g = 0; nb < p.bumpers && g < 400; g++) {
    const x = 1 + Math.floor(rand() * (cols - 2));
    const y = 1 + Math.floor(rand() * (rows - 2));
    const i = y * cols + x;
    if (bumpers[i] || bumpers[i - 1] || bumpers[i + 1] || bumpers[i - cols] || bumpers[i + cols]) continue;
    bumpers[i] = rand() < 0.5 ? 1 : 2;
    nb++;
  }

  const arrows: GenArrow[] = [];
  /** blockers[v] = arrows sitting on v's exit ray (they must leave before v). */
  const blockers: number[][] = [];
  /** For each cell: arrows whose exit ray crosses it. */
  const rayOwners: number[][] = [];
  for (let i = 0; i < n; i++) rayOwners.push([]);

  /** Marks `from` and everything that must leave before it. */
  const markAncestors = (from: number[], seen: Uint8Array) => {
    const stack = from.slice();
    while (stack.length) {
      const j = stack.pop() as number;
      if (seen[j]) continue;
      seen[j] = 1;
      for (const k of blockers[j]) if (!seen[k]) stack.push(k);
    }
  };

  const candidate = (hi: number, d: Dir, minOk: number): GenArrow | null => {
    const hx = hi % cols;
    const hy = (hi - hx) / cols;
    const tr = tracePath(cols, rows, empty, bumpers, { x: hx, y: hy }, d);
    if (tr.blockedBy !== -1) return null;
    const ray = tr.path.map((c) => c.y * cols + c.x);
    if (ray.indexOf(hi) !== -1) return null;

    const span = p.maxLen - p.minLen + 1;
    const want = p.minLen + Math.floor(Math.pow(rand(), 1.7) * span);
    const cells: Cell[] = [{ x: hx, y: hy }];
    const used = [hi];
    let cx = hx;
    let cy = hy;
    let gd: Dir = OPP[d];
    for (let i = 1; i < want; i++) {
      const left = ((gd + 3) % 4) as Dir;
      const right = ((gd + 1) % 4) as Dir;
      const side: Dir[] = rand() < 0.5 ? [left, right] : [right, left];
      let options: Dir[];
      if (i === 1 || p.bend <= 0) options = [gd]; // the neck always sits straight behind the head
      else if (rand() < p.bend) options = [side[0], side[1], gd];
      else options = [gd, side[0], side[1]];
      let grown = false;
      for (const od of options) {
        const nx = cx + DX[od];
        const ny = cy + DY[od];
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        const ni = ny * cols + nx;
        if (occ[ni] !== -1 || bumpers[ni] || used.indexOf(ni) !== -1 || ray.indexOf(ni) !== -1) continue;
        cells.push({ x: nx, y: ny });
        used.push(ni);
        cx = nx;
        cy = ny;
        gd = od;
        grown = true;
        break;
      }
      if (!grown) break;
    }
    if (cells.length < minOk) return null;
    cells.reverse();
    return { cells, dir: d, ray };
  };

  const usable = n - nb;
  const target = Math.round(p.fill * usable);
  let covered = 0;
  let fails = 0;
  while (covered < target && fails < 40) {
    const empties: number[] = [];
    for (let i = 0; i < n; i++) if (occ[i] === -1 && !bumpers[i]) empties.push(i);
    if (!empties.length) break;
    const minOk = fails > 10 ? 1 : p.minLen;

    let best: GenArrow | null = null;
    let bestB: number[] = [];
    let bestD: number[] = [];
    let bestScore = -Infinity;
    for (let k = 0; k < 10; k++) {
      const hi = empties[Math.floor(rand() * empties.length)];
      for (let d = 0; d < 4; d++) {
        const c = candidate(hi, d as Dir, minOk);
        if (!c) continue;
        // B: arrows in this one's way.  D: arrows this one would get in the way of.
        const B: number[] = [];
        for (const r of c.ray) {
          const o = occ[r];
          if (o >= 0 && B.indexOf(o) === -1) B.push(o);
        }
        const D: number[] = [];
        for (const cell of c.cells) {
          for (const o of rayOwners[cell.y * cols + cell.x]) if (D.indexOf(o) === -1) D.push(o);
        }
        if (B.length && D.length) {
          const seen = new Uint8Array(arrows.length);
          markAncestors(B, seen);
          let cyclic = false;
          for (const o of D) if (seen[o]) cyclic = true;
          if (cyclic) continue;
        }
        let score = c.cells.length * 0.45 + rand() * 1.6;
        for (const o of D) score += blockers[o].length ? p.pileW : p.lockW;
        if (B.length) score += p.buryW;
        else if (c.ray.length === 0) score -= p.edgePen;
        if (score > bestScore) {
          bestScore = score;
          best = c;
          bestB = B;
          bestD = D;
        }
      }
    }
    if (!best) {
      fails++;
      continue;
    }
    if (best.ray.length === 0 && bestD.length === 0 && arrows.length > 2 && rand() < p.noFree) {
      fails++;
      continue;
    }
    const id = arrows.length;
    blockers.push(bestB);
    for (const o of bestD) blockers[o].push(id);
    for (const c of best.cells) occ[c.y * cols + c.x] = id;
    for (const r of best.ray) rayOwners[r].push(id);
    arrows.push(best);
    covered += best.cells.length;
  }

  // Grow tails into leftover gaps (same acyclicity rule as above).
  const gaps: number[] = [];
  for (let i = 0; i < n; i++) if (occ[i] === -1 && !bumpers[i]) gaps.push(i);
  shuffle(gaps, rand);
  for (let pass = 0; pass < 2; pass++) {
    for (const g of gaps) {
      if (occ[g] !== -1) continue;
      const gx = g % cols;
      const gy = (g - gx) / cols;
      for (const d of shuffle<Dir>([0, 1, 2, 3], rand)) {
        const nx = gx + DX[d];
        const ny = gy + DY[d];
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        const id = occ[ny * cols + nx];
        if (id < 0) continue;
        const a = arrows[id];
        if (a.cells.length >= p.maxLen) continue;
        const tail = a.cells[0];
        if (tail.x !== nx || tail.y !== ny) continue;
        if (a.cells.length === 1 && d !== a.dir) continue; // keep the neck straight
        if (a.ray.indexOf(g) !== -1) continue;
        const seen = new Uint8Array(arrows.length);
        markAncestors([id], seen);
        let ok = true;
        for (const o of rayOwners[g]) if (seen[o]) ok = false;
        if (!ok) continue;
        a.cells.unshift({ x: gx, y: gy });
        occ[g] = id;
        for (const o of rayOwners[g]) if (blockers[o].indexOf(id) === -1) blockers[o].push(id);
        break;
      }
    }
  }

  const count = arrows.length;
  const frost = new Array<number>(count).fill(0);
  const fuse = new Array<number>(count).fill(0);

  const closureOf = (i: number): number[] => {
    const seen = new Uint8Array(count);
    markAncestors(blockers[i], seen);
    const out: number[] = [];
    for (let j = 0; j < count; j++) if (seen[j]) out.push(j);
    return out;
  };

  // Bombs: buried arrows with a fuse long enough to dig them out (EDF-feasible).
  const bombNeeds = new Uint8Array(count);
  if (p.bombs > 0) {
    const pool = arrows
      .map((a, i) => ({ i, c: closureOf(i), len: a.cells.length }))
      .filter((e) => e.len >= 2 && e.c.length >= 1 && e.c.length <= 8)
      .map((e) => ({ ...e, w: Math.abs(e.c.length - 3.5) + rand() * 2 }))
      .sort((a, b) => a.w - b.w)
      .slice(0, p.bombs)
      .map((e) => ({ ...e, f: e.c.length + 1 + p.slack }))
      .sort((a, b) => a.f - b.f);
    let unionSize = 0;
    for (const e of pool) {
      for (const j of [e.i, ...e.c]) {
        if (!bombNeeds[j]) {
          bombNeeds[j] = 1;
          unionSize++;
        }
      }
      fuse[e.i] = Math.max(e.f, unionSize + p.slack);
    }
  }

  // Frost candidates: arrows that would otherwise look ready early.
  const frostPool =
    p.frozen > 0
      ? arrows
          .map((a, i) => ({ i, len: a.cells.length, w: blockers[i].length + rand() * 1.5 }))
          .filter((e) => e.len >= 2 && !bombNeeds[e.i])
          .sort((a, b) => a.w - b.w)
          .slice(0, p.frozen * 2 + 1)
          .map((e) => e.i)
      : [];
  const wantsFrost = new Uint8Array(count);
  for (const i of frostPool) wantsFrost[i] = 1;

  // One known-good clearing order (Kahn), delaying frost candidates so they
  // get the highest possible rank.
  const rank = new Array<number>(count).fill(0);
  const pending = blockers.map((b) => b.length);
  const unlocks: number[][] = arrows.map(() => []);
  blockers.forEach((b, v) => b.forEach((u) => unlocks[u].push(v)));
  const done = new Uint8Array(count);
  for (let r = 0; r < count; r++) {
    let pick = -1;
    for (let i = 0; i < count; i++) {
      if (done[i] || pending[i] > 0) continue;
      if (pick === -1 || (wantsFrost[pick] && !wantsFrost[i])) pick = i;
    }
    if (pick === -1) break; // unreachable: the graph is acyclic
    done[pick] = 1;
    rank[pick] = r;
    for (const v of unlocks[pick]) pending[v]--;
  }

  // `frost ≤ rank` guarantees the lowest-ranked arrow left is always playable.
  const maxK = level >= 10 ? 5 : 4;
  let iced = 0;
  for (const i of frostPool) {
    if (iced >= p.frozen) break;
    if (rank[i] < 2) continue;
    frost[i] = Math.min(rank[i], 2 + Math.floor(rand() * (maxK - 1)));
    iced++;
  }

  return {
    level,
    cols,
    rows,
    bumpers,
    arrows: arrows.map((a, i) => ({ id: i, cells: a.cells, dir: a.dir, frost: frost[i], fuse: fuse[i], rank: rank[i] })),
  };
}

/** `wide` lays the board out landscape (for short, wide screens). */
export function generateLevel(level: number, rand: () => number = Math.random, wide = false): LevelDef {
  const p = paramsFor(level);
  if (wide && p.rows > p.cols) {
    const t = p.cols;
    p.cols = p.rows;
    p.rows = t;
  }
  const minArrows = Math.max(4, Math.round((p.cols * p.rows) / 6));
  let last: LevelDef | null = null;
  for (let attempt = 0; attempt < 40; attempt++) {
    const def = build(level, p, rand);
    last = def;
    if (def.arrows.length < minArrows || countFree(def) < 2) continue;
    if (verifyLevel(def)) return def;
    // Extremely unlikely, but never ship an unfair board: strip the modifiers.
    for (const a of def.arrows) {
      a.frost = 0;
      a.fuse = 0;
    }
    if (verifyLevel(def)) return def;
  }
  const def = last as LevelDef;
  for (const a of def.arrows) {
    a.frost = 0;
    a.fuse = 0;
  }
  return def;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
