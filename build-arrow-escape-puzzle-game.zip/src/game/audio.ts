/**
 * Tiny synthesized sound kit — every effect is generated with WebAudio so the
 * game ships without audio files.
 */

type Wave = OscillatorType;

interface ToneOpts {
  type?: Wave;
  vol?: number;
  slideTo?: number;
  delay?: number;
  attack?: number;
}

interface NoiseOpts {
  vol?: number;
  filter?: BiquadFilterType;
  freq?: number;
  slideTo?: number;
  q?: number;
  delay?: number;
}

// Major pentatonic steps: each combo hit climbs the scale.
const SCALE = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26, 28];

class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  muted = false;

  /** Must be called from a user gesture before anything is audible. */
  unlock() {
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext | undefined =
          window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        const comp = this.ctx.createDynamicsCompressor();
        comp.threshold.value = -14;
        comp.ratio.value = 6;
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.55;
        this.master.connect(comp);
        comp.connect(this.ctx.destination);

        const len = Math.floor(this.ctx.sampleRate * 0.6);
        this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const data = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      }
      if (this.ctx.state === 'suspended') void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.02);
    }
  }

  private tone(freq: number, dur: number, o: ToneOpts = {}) {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted) return;
    const t0 = ctx.currentTime + (o.delay ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = o.type ?? 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    if (o.slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.slideTo), t0 + dur);
    const vol = o.vol ?? 0.2;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + (o.attack ?? 0.008));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.03);
  }

  private noise(dur: number, o: NoiseOpts = {}) {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noiseBuf || this.muted) return;
    const t0 = ctx.currentTime + (o.delay ?? 0);
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = o.filter ?? 'bandpass';
    f.frequency.setValueAtTime(o.freq ?? 1200, t0);
    if (o.slideTo) f.frequency.exponentialRampToValueAtTime(Math.max(20, o.slideTo), t0 + dur);
    f.Q.value = o.q ?? 0.8;
    const g = ctx.createGain();
    g.gain.setValueAtTime(o.vol ?? 0.2, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t0);
    src.stop(t0 + dur + 0.03);
  }

  private note(step: number, base = 392) {
    const s = SCALE[Math.min(Math.max(step, 0), SCALE.length - 1)];
    return base * Math.pow(2, s / 12);
  }

  /** Arrow launched. Pitch climbs with the combo. */
  launch(combo: number) {
    const f = this.note(combo - 1, 330);
    this.tone(f, 0.16, { type: 'triangle', vol: 0.3, slideTo: f * 1.25 });
    this.tone(f * 2, 0.1, { type: 'sine', vol: 0.12, delay: 0.02 });
    this.noise(0.18, { vol: 0.16, filter: 'bandpass', freq: 900, slideTo: 5200, q: 1.2 });
  }

  /** Arrow crossed the board edge. */
  exit() {
    this.noise(0.09, { vol: 0.07, filter: 'highpass', freq: 3500 });
  }

  blocked() {
    this.tone(150, 0.22, { type: 'square', vol: 0.22, slideTo: 62 });
    this.tone(96, 0.26, { type: 'sine', vol: 0.34, slideTo: 44 });
    this.noise(0.14, { vol: 0.28, filter: 'lowpass', freq: 900, slideTo: 180 });
  }

  bumper() {
    this.tone(1320, 0.12, { type: 'triangle', vol: 0.14, slideTo: 1760 });
    this.tone(2640, 0.08, { type: 'sine', vol: 0.06, delay: 0.015 });
  }

  frozen() {
    this.tone(1900, 0.07, { type: 'triangle', vol: 0.12 });
    this.tone(1500, 0.09, { type: 'triangle', vol: 0.1, delay: 0.05 });
  }

  frostTick() {
    this.tone(2300, 0.05, { type: 'sine', vol: 0.06 });
  }

  thaw() {
    this.noise(0.22, { vol: 0.2, filter: 'highpass', freq: 2600, slideTo: 7000 });
    this.tone(1560, 0.2, { type: 'triangle', vol: 0.12, slideTo: 2350 });
    this.tone(2090, 0.22, { type: 'sine', vol: 0.08, delay: 0.06, slideTo: 3100 });
  }

  fuseTick(urgent: boolean) {
    this.tone(urgent ? 990 : 660, 0.05, { type: 'square', vol: urgent ? 0.11 : 0.06 });
    if (urgent) this.tone(990, 0.05, { type: 'square', vol: 0.11, delay: 0.09 });
  }

  defuse() {
    this.tone(660, 0.1, { type: 'triangle', vol: 0.18 });
    this.tone(990, 0.16, { type: 'triangle', vol: 0.18, delay: 0.08 });
  }

  explode() {
    this.noise(0.5, { vol: 0.5, filter: 'lowpass', freq: 1800, slideTo: 90, q: 0.4 });
    this.tone(110, 0.45, { type: 'sine', vol: 0.5, slideTo: 30 });
    this.tone(70, 0.3, { type: 'square', vol: 0.18, slideTo: 28 });
  }

  move() {
    this.tone(540, 0.035, { type: 'triangle', vol: 0.05 });
  }

  click() {
    this.tone(480, 0.06, { type: 'triangle', vol: 0.12, slideTo: 720 });
  }

  hint() {
    this.tone(880, 0.1, { type: 'sine', vol: 0.14 });
    this.tone(1175, 0.16, { type: 'sine', vol: 0.14, delay: 0.09 });
  }

  nope() {
    this.tone(210, 0.08, { type: 'triangle', vol: 0.1, slideTo: 170 });
  }

  levelClear() {
    [0, 2, 4, 5, 7].forEach((s, i) => {
      const f = this.note(s, 392);
      this.tone(f, 0.24, { type: 'triangle', vol: 0.22, delay: i * 0.085 });
      this.tone(f * 2, 0.2, { type: 'sine', vol: 0.07, delay: i * 0.085 });
    });
    this.noise(0.35, { vol: 0.08, filter: 'highpass', freq: 5000, delay: 0.34 });
  }

  star(i: number) {
    this.tone(this.note(3 + i * 2, 440), 0.2, { type: 'triangle', vol: 0.16 });
  }

  gameOver() {
    [392, 330, 262, 196].forEach((f, i) => {
      this.tone(f, 0.34, { type: 'triangle', vol: 0.22, delay: i * 0.17, slideTo: f * 0.94 });
    });
  }

  start() {
    [0, 2, 4].forEach((s, i) => this.tone(this.note(s, 392), 0.16, { type: 'triangle', vol: 0.2, delay: i * 0.07 }));
  }
}

export const sfx = new Sfx();

export function buzz(pattern: number | number[]) {
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(pattern);
  } catch {
    /* unsupported */
  }
}
