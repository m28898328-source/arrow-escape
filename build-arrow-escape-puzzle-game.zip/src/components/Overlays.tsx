import { useEffect, useRef, type CSSProperties } from 'react';
import { sfx } from '../game/audio';
import type { FinalResult, LevelResult } from '../game/engine';
import { NAME_MAX, type ScoreEntry } from '../game/storage';
import { Heart, Icon, MiniArrow, ScoreTable, Star, fmt, useCountUp } from './ui';

const INK = '#221C35';
const TITLE_FONT = '"Lilita One", "Arial Rounded MT Bold", "Trebuchet MS", system-ui, sans-serif';
const stagger = (i: number) => ({ '--i': i }) as CSSProperties;

/* ------------------------------------------------------------------ */
/* Start screen                                                        */
/* ------------------------------------------------------------------ */

function Title() {
  return (
    <div className="rise relative w-full" style={stagger(1)}>
      <h1 className="sr-only">Arrow Escape</h1>
      <div className="title-bob mx-auto w-full max-w-[430px] short:max-w-[250px]">
        <svg viewBox="0 0 520 262" className="block w-full overflow-visible" aria-hidden="true">
          <g fontFamily={TITLE_FONT} fontSize={134} textAnchor="middle" strokeLinejoin="round" letterSpacing="1">
            <g fill={INK} stroke={INK} strokeWidth={20} transform="translate(0 10)">
              <text x="260" y="114">
                ARROW
              </text>
              <text x="260" y="238">
                ESCAPE
              </text>
            </g>
            <g stroke={INK} strokeWidth={16} style={{ paintOrder: 'stroke' }}>
              <text x="260" y="114" fill="#FFFBF0">
                ARROW
              </text>
              <text x="260" y="238" fill="#F9B208">
                ESCAPE
              </text>
            </g>
          </g>
        </svg>
        <div className="absolute -top-[7%] right-[1%] rotate-[-32deg]">
          <MiniArrow dir={1} long size={38} color="#F2553D" />
        </div>
      </div>
    </div>
  );
}

interface MenuProps {
  best: number;
  muted: boolean;
  onPlay: () => void;
  onScores: () => void;
  onMute: () => void;
}

export function Menu({ best, muted, onPlay, onScores, onMute }: MenuProps) {
  return (
    <div className="overlay safe-area">
      <div className="menu-glow" />
      <div className="relative flex w-full max-w-[440px] flex-col items-center py-2 text-center">
        <p
          className="rise rounded-full bg-ink px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-card"
          style={stagger(0)}
        >
          A sliding arrow puzzle
        </p>

        <div className="mt-4 w-full">
          <Title />
        </div>

        <p className="rise mt-3 max-w-[330px] text-[15px] font-medium leading-snug text-ink-soft short:hidden" style={stagger(2)}>
          Launch every arrow off the board. Crash into another one and you lose a heart.
        </p>

        <div className="rise mt-6 short:mt-4" style={stagger(3)}>
          <button type="button" className="btn btn-primary btn-xl" autoFocus onClick={onPlay}>
            Play
            <Icon name="play" size={26} />
          </button>
        </div>

        <div className="rise mt-4 flex gap-2.5" style={stagger(4)}>
          <button type="button" className="btn" onClick={onScores}>
            <Icon name="trophy" size={20} />
            High scores
          </button>
          <button
            type="button"
            className="btn btn-icon"
            onClick={onMute}
            title={muted ? 'Sound off (M)' : 'Sound on (M)'}
            aria-label={muted ? 'Unmute sound' : 'Mute sound'}
          >
            <Icon name={muted ? 'soundOff' : 'soundOn'} />
          </button>
        </div>

        <ul className="rise mt-7 grid w-full grid-cols-3 gap-2.5 short:hidden" style={stagger(5)}>
          <li className="chip flex flex-col items-center gap-1.5 px-1.5 py-2.5">
            <span className="flex h-8 items-center">
              <MiniArrow dir={1} long size={24} />
            </span>
            <span className="text-[12px] font-semibold leading-tight">Tap an arrow to launch it</span>
          </li>
          <li className="chip flex flex-col items-center gap-1.5 px-1.5 py-2.5">
            <span className="flex h-8 items-center gap-0.5">
              <MiniArrow dir={1} size={24} />
              <MiniArrow dir={0} size={24} />
              <Heart size={18} className="-ml-0.5" />
            </span>
            <span className="text-[12px] font-semibold leading-tight">Blocked? That costs a heart</span>
          </li>
          <li className="chip flex flex-col items-center gap-1.5 px-1.5 py-2.5">
            <span className="grid h-8 grid-cols-4 items-center gap-0.5">
              <MiniArrow dir={0} size={17} />
              <MiniArrow dir={1} size={17} />
              <MiniArrow dir={2} size={17} />
              <MiniArrow dir={3} size={17} />
            </span>
            <span className="text-[12px] font-semibold leading-tight">Colour shows direction</span>
          </li>
        </ul>

        <div className="rise mt-5 flex min-h-6 flex-wrap items-center justify-center gap-x-4 gap-y-1 text-[12.5px] font-medium text-ink-soft" style={stagger(6)}>
          {best > 0 && (
            <span>
              Best <b className="font-display text-[15px] font-normal text-ink">{fmt(best)}</b>
            </span>
          )}
          <span className="hidden items-center gap-1.5 pointer-fine:flex">
            <span className="kbd">Enter</span> to play
          </span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* High scores                                                         */
/* ------------------------------------------------------------------ */

export function ScoresModal({ scores, onClose }: { scores: ScoreEntry[]; onClose: () => void }) {
  return (
    <div
      className="overlay scrim safe-area z-40"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="card pop-in w-full max-w-[400px] p-5" role="dialog" aria-modal="true" aria-label="High scores">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-[28px] leading-none">
            <Icon name="trophy" size={26} />
            High scores
          </h2>
          <button type="button" className="btn btn-icon" onClick={onClose} aria-label="Close high scores">
            <Icon name="close" />
          </button>
        </div>
        <ScoreTable scores={scores} maxHeight={372} />
        <button type="button" className="btn btn-primary btn-lg mt-5 w-full" autoFocus onClick={onClose}>
          Back
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Pause                                                               */
/* ------------------------------------------------------------------ */

interface PauseProps {
  level: number;
  score: number;
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onMute: () => void;
}

export function Pause({ level, score, muted, onResume, onRestart, onMenu, onMute }: PauseProps) {
  return (
    <div className="overlay scrim safe-area">
      <div className="card pop-in w-full max-w-[340px] p-6 text-center" role="dialog" aria-modal="true" aria-label="Game paused">
        <h2 className="font-display text-[42px] leading-none">Paused</h2>
        <p className="mt-1.5 text-sm font-medium text-ink-soft">
          Level {level} · {fmt(score)} pts
        </p>
        <p className="mt-1 text-[12.5px] font-medium text-ink-soft">The board stays hidden while the clock is stopped.</p>
        <div className="mt-5 flex flex-col gap-3.5">
          <button type="button" className="btn btn-primary btn-lg" autoFocus onClick={onResume}>
            <Icon name="play" />
            Resume
          </button>
          <button type="button" className="btn btn-lg" onClick={onRestart}>
            <Icon name="restart" />
            Restart
          </button>
          <div className="grid grid-cols-2 gap-3">
            <button type="button" className="btn" onClick={onMute} aria-pressed={!muted}>
              <Icon name={muted ? 'soundOff' : 'soundOn'} size={20} />
              {muted ? 'Sound off' : 'Sound on'}
            </button>
            <button type="button" className="btn" onClick={onMenu}>
              <Icon name="home" size={20} />
              Menu
            </button>
          </div>
        </div>
        <p className="mt-5 hidden flex-wrap items-center justify-center gap-x-1.5 gap-y-1 text-[12px] font-medium text-ink-soft pointer-fine:flex">
          <span className="kbd">P</span> resume
          <span className="kbd ml-1.5">R</span> restart
          <span className="kbd ml-1.5">M</span> sound
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Level clear                                                         */
/* ------------------------------------------------------------------ */

export function LevelClear({ result, onNext }: { result: LevelResult; onNext: () => void }) {
  useEffect(() => {
    const timers: number[] = [];
    for (let i = 0; i < result.stars; i++) {
      timers.push(window.setTimeout(() => sfx.star(i), 260 + i * 170));
    }
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [result]);

  const headline = result.stars === 3 ? 'Perfect!' : result.stars === 2 ? 'Nice work!' : 'Cleared!';
  const rows: { label: string; value: number; dim?: boolean }[] = [
    { label: 'Board cleared', value: result.clearBonus },
    { label: `Speed (${result.seconds.toFixed(1)}s)`, value: result.timeBonus, dim: result.timeBonus === 0 },
    {
      label: result.mistakes === 0 ? 'No mistakes' : `${result.mistakes} ${result.mistakes === 1 ? 'mistake' : 'mistakes'}`,
      value: result.perfectBonus,
      dim: result.perfectBonus === 0,
    },
  ];

  return (
    <div className="overlay scrim safe-area">
      <div className="card pop-in w-full max-w-[350px] p-6 text-center" role="dialog" aria-modal="true" aria-label="Level complete">
        <div className="flex items-end justify-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <Star
              key={i}
              filled={i < result.stars}
              size={i === 1 ? 62 : 48}
              className="star"
              style={{ animationDelay: `${0.22 + i * 0.17}s`, marginBottom: i === 1 ? 6 : 0 }}
            />
          ))}
        </div>
        <h2 className="mt-2 font-display text-[40px] leading-none">{headline}</h2>
        <p className="mt-1.5 text-sm font-medium text-ink-soft">Level {result.level} complete</p>

        <dl className="mt-4 overflow-hidden rounded-2xl border-[2.5px] border-ink bg-white text-[15px]">
          {rows.map((r) => (
            <div key={r.label} className={`flex items-center justify-between px-3.5 py-2 ${r.dim ? 'text-ink-soft' : ''}`}>
              <dt className="font-medium">{r.label}</dt>
              <dd className="font-display text-[17px] leading-none tabular-nums">+{fmt(r.value)}</dd>
            </div>
          ))}
          <div className="flex items-center justify-between border-t-[2.5px] border-ink bg-arrow-left px-3.5 py-2.5">
            <dt className="font-display text-[17px] leading-none">Bonus</dt>
            <dd className="font-display text-[22px] leading-none tabular-nums">+{fmt(result.total)}</dd>
          </div>
        </dl>

        <p className="mt-3 flex min-h-6 items-center justify-center gap-1.5 text-[13px] font-semibold">
          {result.healed && (
            <>
              <Heart size={18} /> +1 life restored
            </>
          )}
        </p>

        <button type="button" className="btn btn-go btn-lg mt-2 w-full" autoFocus onClick={onNext}>
          Next level
          <Icon name="next" />
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Game over                                                           */
/* ------------------------------------------------------------------ */

interface GameOverProps {
  final: FinalResult;
  scores: ScoreEntry[];
  playerName: string;
  onRename: (name: string) => void;
  onRestart: () => void;
  onMenu: () => void;
}

export function GameOver({ final, scores, playerName, onRename, onRestart, onMenu }: GameOverProps) {
  const shown = useCountUp(final.score, 900, 0);
  const againRef = useRef<HTMLButtonElement>(null);
  const placed = final.rank >= 0;

  return (
    <div className="overlay scrim safe-area">
      <div className="card pop-in w-full max-w-[400px] p-5 text-center" role="dialog" aria-modal="true" aria-label="Game over">
        <h2 className="font-display text-[42px] leading-none">Game over</h2>

        <div className="mt-2 flex min-h-8 items-center justify-center">
          {final.rank === 0 ? (
            <span className="ribbon inline-block rounded-full border-[2.5px] border-ink bg-arrow-left px-3.5 py-1 font-display text-[15px] leading-none">
              New high score!
            </span>
          ) : placed ? (
            <span className="inline-block rounded-full border-[2.5px] border-ink bg-ice px-3.5 py-1 font-display text-[15px] leading-none">
              #{final.rank + 1} on the board
            </span>
          ) : (
            <span className="text-sm font-medium text-ink-soft">Out of lives on level {final.level}</span>
          )}
        </div>

        <div className="mt-1 font-display text-[58px] leading-none tabular-nums">{fmt(shown)}</div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { k: 'Level', v: String(final.level) },
            { k: 'Arrows', v: String(final.cleared) },
            { k: 'Combo', v: `×${final.bestCombo}` },
          ].map((s) => (
            <div key={s.k} className="rounded-xl border-[2.5px] border-ink bg-white px-1 py-1.5">
              <div className="label">{s.k}</div>
              <div className="font-display text-[20px] leading-tight">{s.v}</div>
            </div>
          ))}
        </div>

        {placed && (
          <label className="mt-3.5 block text-left">
            <span className="label mb-1 block">Your name</span>
            <input
              className="name-input"
              type="text"
              defaultValue={playerName}
              maxLength={NAME_MAX}
              autoComplete="off"
              autoCapitalize="words"
              spellCheck={false}
              enterKeyHint="done"
              onChange={(e) => onRename(e.target.value)}
              onFocus={(e) => e.target.select()}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  againRef.current?.focus();
                }
              }}
            />
          </label>
        )}

        <div className="mt-3.5 text-left">
          <ScoreTable scores={scores} highlightId={placed ? final.entryId : undefined} maxHeight={placed ? 132 : 166} />
        </div>

        <div className="mt-5 grid grid-cols-[1fr_auto] gap-3">
          <button ref={againRef} type="button" className="btn btn-primary btn-lg" autoFocus onClick={onRestart}>
            <Icon name="restart" />
            Play again
          </button>
          <button type="button" className="btn btn-lg" onClick={onMenu} aria-label="Back to menu">
            <Icon name="home" />
          </button>
        </div>
        <p className="mt-4 hidden items-center justify-center gap-1.5 text-[12px] font-medium text-ink-soft pointer-fine:flex">
          <span className="kbd">Enter</span> or <span className="kbd">R</span> to play again
        </p>
      </div>
    </div>
  );
}
