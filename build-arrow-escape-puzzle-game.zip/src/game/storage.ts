/** Local persistence for the high-score table and player settings. */

export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  level: number;
  date: number;
}

export interface Settings {
  muted: boolean;
  name: string;
}

const SCORES_KEY = 'arrow-escape:v1:scores';
const SETTINGS_KEY = 'arrow-escape:v1:settings';
export const MAX_SCORES = 10;
export const NAME_MAX = 12;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable (private mode, quota) — play on without saving */
  }
}

export function cleanName(name: string): string {
  const n = name.replace(/\s+/g, ' ').trim().slice(0, NAME_MAX);
  return n || 'Player';
}

export function loadScores(): ScoreEntry[] {
  const list = read<unknown>(SCORES_KEY, []);
  if (!Array.isArray(list)) return [];
  return (list as Partial<ScoreEntry>[])
    .filter((e) => e && typeof e.score === 'number' && typeof e.name === 'string')
    .map((e) => ({
      id: String(e.id ?? Math.random()),
      name: cleanName(e.name as string),
      score: Math.max(0, Math.floor(e.score as number)),
      level: Math.max(1, Math.floor(e.level ?? 1)),
      date: e.date ?? 0,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, MAX_SCORES);
}

/** Inserts a score. `rank` is the 0-based table position, or -1 if it missed the cut. */
export function addScore(name: string, score: number, level: number): { list: ScoreEntry[]; rank: number; id: string } {
  const id = `${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
  const entry: ScoreEntry = { id, name: cleanName(name), score, level, date: Date.now() };
  const list = loadScores();
  if (score <= 0) return { list, rank: -1, id };
  // Ties rank below existing entries: first to reach a score keeps the spot.
  let rank = list.findIndex((e) => score > e.score);
  if (rank === -1) rank = list.length;
  if (rank >= MAX_SCORES) return { list, rank: -1, id };
  list.splice(rank, 0, entry);
  const trimmed = list.slice(0, MAX_SCORES);
  write(SCORES_KEY, trimmed);
  return { list: trimmed, rank, id };
}

export function renameScore(id: string, name: string): ScoreEntry[] {
  const list = loadScores().map((e) => (e.id === id ? { ...e, name: cleanName(name) } : e));
  write(SCORES_KEY, list);
  return list;
}

export function clearScores() {
  write(SCORES_KEY, []);
}

export function loadSettings(): Settings {
  const s = read<Partial<Settings>>(SETTINGS_KEY, {});
  return {
    muted: !!s.muted,
    name: typeof s.name === 'string' && s.name.trim() ? cleanName(s.name) : 'Player',
  };
}

export function saveSettings(s: Settings) {
  write(SETTINGS_KEY, s);
}
