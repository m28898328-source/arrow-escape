import { buzz, sfx } from './audio';
import {
  BOMB_LEVEL,
  BUMPER_LEVEL,
  DX,
  DY,
  FROST_LEVEL,
  generateLevel,
  geometricRay,
  suggestMove,
  tracePath,
  type Cell,
  type Dir,
  type SolverArrow,
  type Trace,
} from './level';
import { addScore, cleanName, loadScores, loadSettings, renameScore, saveSettings, type ScoreEntry } from './storage';

/* ------------------------------------------------------------------ */
/* Public types                                                        */
/* ------------------------------------------------------------------ */

export type Phase = 'menu' | 'playing' | 'paused' | 'levelclear' | 'gameover';

export interface Tip {
  kind: 'tap' | 'heart' | 'bumper' | 'frost' | 'bomb';
  title: string;
  text: string;
}

export interface LevelResult {
  level: number;
  seconds: number;
  mistakes: number;
  stars: number;
  clearBonus: number;
  timeBonus: number;
  perfectBonus: number;
  total: number;
  healed: boolean;
}

export interface FinalResult {
  score: number;
  level: number;
  cleared: number;
  bestCombo: number;
  /** 0-based position in the table, -1 if the run did not place. */
  rank: number;
  entryId: string;
}

export interface Snapshot {
  phase: Phase;
  level: number;
  score: number;
  best: number;
  hearts: number;
  hints: number;
  combo: number;
  comboKey: number;
  arrowsLeft: number;
  arrowsTotal: number;
  muted: boolean;
  hurtKey: number;
  tip: Tip | null;
  result: LevelResult | null;
  final: FinalResult | null;
  scores: ScoreEntry[];
  playerName: string;
}

export const MAX_HEARTS = 3;
export const MAX_HINTS = 3;
export const COMBO_WINDOW = 3.5;

/* ------------------------------------------------------------------ */
/* Look & feel constants                                               */
/* ------------------------------------------------------------------ */

const INK = '#221C35';
const TRAY = '#FFFBF0';
const SOCKET = '#F1E7D0';
const DROP = '#D9CDB0';
const BOMB_BODY = '#3B3456';
const BOMB_LIGHT = '#6A6190';
const FROST_OUTLINE = '#2B5C8A';
const BUMPER = '#8B6CF6';
const BUMPER_LIGHT = '#CDBEFF';
const DANGER = '#F0435E';

/** Colour is tied to heading, so direction reads at a glance: up, right, down, left. */
export const PALETTE = [
  { fill: '#F2553D', light: '#FF9A82' },
  { fill: '#2E6BE6', light: '#7FAEFF' },
  { fill: '#14B87F', light: '#6CE5B6' },
  { fill: '#F9B208', light: '#FFDD6B' },
] as const;

const FONT = '"Lilita One", "Arial Rounded MT Bold", "Trebuchet MS", system-ui, sans-serif';

// Arrow geometry, in cell units.
const BODY_W = 0.34;
const OUTLINE = 0.05;
const TAIL_EXT = 0.24;
const CORNER_R = 0.3;
const HEAD_TIP = 0.37;
const HEAD_BACK = 0.07;
const HEAD_HALF = 0.31;
const HEAD_ROUND = 0.05;

const IDLE = 0;
const EXIT = 1;
const BUMP = 2;
const FALL = 3;
const DEAD = 4;

const TIPS: Record<number, Tip> = {
  1: { kind: 'tap', title: 'Tap an arrow', text: 'It flies off the board if nothing is in its way.' },
  2: { kind: 'heart', title: 'Look before you launch', text: 'A blocked arrow costs a heart. Chain quick escapes for combos.' },
  [BUMPER_LEVEL]: { kind: 'bumper', title: 'New: bumpers', text: 'Arrows bounce off them and turn the corner.' },
  [FROST_LEVEL]: { kind: 'frost', title: 'New: frozen arrows', text: 'They thaw after the number of escapes shown.' },
  [BOMB_LEVEL]: { kind: 'bomb', title: 'New: bomb arrows', text: 'Get them out before the fuse hits zero.' },
};

/* ------------------------------------------------------------------ */
/* Internal types                                                      */
/* ------------------------------------------------------------------ */

interface Arrow {
  id: number;
  cells: Cell[];
  dir: Dir;
  len: number;
  frost: number;
  fuse: number;
  bomb: boolean;
  rank: number;
  ray: number[];
  state: number;
  body: Path2D;
  head: Path2D;
  cx: number;
  cy: number;
  tx: number;
  ty: number;
  spawnDelay: number;
  spawn: number;
  nodes: number[];
  t: number;
  v: number;
  pathLen: number;
  turnNodes: number[];
  turnCells: number[];
  turnDone: number;
  exitDir: Dir;
  burst: boolean;
  alpha: number;
  bumpT: number;
  bumpMax: number;
  bumpDur1: number;
  bumpHit: boolean;
  blocker: number;
  hit: number;
  hitDir: Dir;
  wobble: number;
  badgePop: number;
  ox: number;
  oy: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
}

interface Particle {
  kind: number; // 0 confetti, 1 dot, 2 spark, 3 ring, 4 shard
  x: number;
  y: number;
  vx: number;
  vy: number;
  g: number;
  drag: number;
  age: number;
  life: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
}

interface Popup {
  x: number;
  y: number;
  text: string;
  color: string;
  size: number;
  age: number;
  life: number;
  rise: number;
}

interface Gate {
  x: number;
  y: number;
  horizontal: boolean;
  color: string;
  age: number;
}

interface Deco {
  x: number;
  y: number;
  s: number;
  dir: Dir;
  speed: number;
  reach: number;
  body: Path2D;
  head: Path2D;
}

interface Shape {
  body: Path2D;
  head: Path2D;
  hx: number;
  hy: number;
  dx: number;
  dy: number;
}

/* ------------------------------------------------------------------ */
/* Geometry helpers                                                    */
/* ------------------------------------------------------------------ */

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const easeOutBack = (k: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  const u = k - 1;
  return 1 + c3 * u * u * u + c1 * u * u;
};
const easeOutCubic = (k: number) => 1 - Math.pow(1 - k, 3);
const rnd = (a: number, b: number) => a + Math.random() * (b - a);

let sx = 0;
let sy = 0;
/** Point at arc-length `s` (in cells) along a node chain; writes to sx/sy. */
function samplePath(nodes: number[], s: number) {
  const max = (nodes.length >> 1) - 1;
  if (s <= 0) {
    sx = nodes[0] + (nodes[2] - nodes[0]) * s;
    sy = nodes[1] + (nodes[3] - nodes[1]) * s;
    return;
  }
  if (s >= max) {
    const k = s - max;
    sx = nodes[2 * max] + (nodes[2 * max] - nodes[2 * max - 2]) * k;
    sy = nodes[2 * max + 1] + (nodes[2 * max + 1] - nodes[2 * max - 1]) * k;
    return;
  }
  const i = Math.floor(s);
  const f = s - i;
  sx = nodes[2 * i] + (nodes[2 * i + 2] - nodes[2 * i]) * f;
  sy = nodes[2 * i + 1] + (nodes[2 * i + 3] - nodes[2 * i + 1]) * f;
}

function roundedPolyline(p: Path2D, pts: number[], R: number) {
  const n = pts.length >> 1;
  p.moveTo(pts[0], pts[1]);
  for (let i = 1; i < n - 1; i++) {
    const ax = pts[2 * i - 2];
    const ay = pts[2 * i - 1];
    const bx = pts[2 * i];
    const by = pts[2 * i + 1];
    const cx = pts[2 * i + 2];
    const cy = pts[2 * i + 3];
    const l1 = Math.hypot(bx - ax, by - ay);
    const l2 = Math.hypot(cx - bx, cy - by);
    const cross = (bx - ax) * (cy - by) - (by - ay) * (cx - bx);
    if (l1 < 1e-4 || l2 < 1e-4 || Math.abs(cross) < 1e-6) {
      p.lineTo(bx, by);
      continue;
    }
    const r = Math.min(R, i === 1 ? l1 : l1 / 2, i === n - 2 ? l2 : l2 / 2);
    if (r < 0.01) p.lineTo(bx, by);
    else p.arcTo(bx, by, cx, cy, r);
  }
  p.lineTo(pts[2 * n - 2], pts[2 * n - 1]);
}

/**
 * Builds the snake outline for an arrow of `len` cells that has slid `t` cells
 * along its node chain. t = 0 with resting nodes gives the idle shape.
 */
function buildShape(nodes: number[], len: number, t: number): Shape {
  const count = nodes.length >> 1;
  const sT = t - TAIL_EXT;
  const sH = t + len - 1;
  const pts: number[] = [];
  samplePath(nodes, sT);
  pts.push(sx, sy);
  for (let k = Math.max(0, Math.floor(sT) + 1); k < sH - 1e-4 && k < count; k++) {
    pts.push(nodes[2 * k], nodes[2 * k + 1]);
  }
  samplePath(nodes, sH);
  const hx = sx;
  const hy = sy;
  pts.push(hx, hy);

  let i = Math.floor(sH + 1e-4);
  if (i < 0) i = 0;
  if (i > count - 2) i = count - 2;
  const dx = nodes[2 * i + 2] - nodes[2 * i];
  const dy = nodes[2 * i + 3] - nodes[2 * i + 1];

  const body = new Path2D();
  roundedPolyline(body, pts, CORNER_R);
  const head = new Path2D();
  const px = -dy;
  const py = dx;
  head.moveTo(hx + dx * HEAD_TIP, hy + dy * HEAD_TIP);
  head.lineTo(hx - dx * HEAD_BACK + px * HEAD_HALF, hy - dy * HEAD_BACK + py * HEAD_HALF);
  head.lineTo(hx - dx * HEAD_BACK - px * HEAD_HALF, hy - dy * HEAD_BACK - py * HEAD_HALF);
  head.closePath();
  return { body, head, hx, hy, dx, dy };
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ------------------------------------------------------------------ */
/* Game                                                                */
/* ------------------------------------------------------------------ */

export class Game {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private shakeEl: HTMLElement | null = null;
  private dpr = 1;
  private W = 0;
  private H = 0;
  private area = { x: 0, y: 0, w: 0, h: 0 };
  private S = 48;
  private bx = 0;
  private by = 0;

  private raf = 0;
  private last = 0;
  private time = 0;
  private listeners = new Set<() => void>();
  private snap: Snapshot;
  private reduceMotion = false;

  // Run state
  private phase: Phase = 'menu';
  private level = 1;
  private score = 0;
  private hearts = MAX_HEARTS;
  private hints = MAX_HINTS;
  private combo = 0;
  private comboTimer = 0;
  private comboKey = 0;
  private bestCombo = 0;
  private cleared = 0;
  private mistakes = 0;
  private levelTime = 0;
  private remaining = 0;
  private total = 0;
  private locked = false;
  private pendingClear = -1;
  private pendingOver = -1;
  private lockUntil = 0;
  private hurtKey = 0;
  private idle = 0;
  private result: LevelResult | null = null;
  private final: FinalResult | null = null;
  private scores: ScoreEntry[] = [];
  private muted = false;
  private playerName = 'Player';

  // Board
  private cols = 0;
  private rows = 0;
  private occ: Int16Array = new Int16Array(0);
  private bumpers: Uint8Array = new Uint8Array(0);
  private bumperPulse: Float32Array = new Float32Array(0);
  private arrows: Arrow[] = [];
  private byId = new Map<number, Arrow>();
  private boardPop = 1;
  private kick = 0;

  // Input
  private hoverId = -1;
  private hintId = -1;
  private cursorX = 0;
  private cursorY = 0;
  private keyboard = false;

  // Effects
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private gates: Gate[] = [];
  private deco: Deco[] = [];
  private decoW = 0;
  private decoH = 0;
  private shake = 0;

  constructor() {
    const settings = loadSettings();
    this.muted = settings.muted;
    this.playerName = settings.name;
    this.scores = loadScores();
    sfx.setMuted(this.muted);
    this.snap = this.makeSnapshot();
  }

  /* ---------------------------- store ----------------------------- */

  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };

  getSnapshot = () => this.snap;

  private makeSnapshot(): Snapshot {
    return {
      phase: this.phase,
      level: this.level,
      score: this.score,
      best: Math.max(this.scores.length ? this.scores[0].score : 0, this.score),
      hearts: this.hearts,
      hints: this.hints,
      combo: this.combo,
      comboKey: this.comboKey,
      arrowsLeft: this.remaining,
      arrowsTotal: this.total,
      muted: this.muted,
      hurtKey: this.hurtKey,
      tip: this.phase === 'playing' || this.phase === 'paused' ? (TIPS[this.level] ?? null) : null,
      result: this.result,
      final: this.final,
      scores: this.scores,
      playerName: this.playerName,
    };
  }

  private emit() {
    this.snap = this.makeSnapshot();
    this.listeners.forEach((fn) => fn());
  }

  /* --------------------------- lifecycle -------------------------- */

  attach(canvas: HTMLCanvasElement, shakeEl: HTMLElement) {
    this.canvas = canvas;
    this.shakeEl = shakeEl;
    this.ctx = canvas.getContext('2d');
    this.reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointermove', this.onPointerMove);
    canvas.addEventListener('pointerleave', this.onPointerLeave);
    try {
      void document.fonts?.load(`20px ${FONT}`);
    } catch {
      /* optional */
    }
    this.resize();
    this.last = performance.now();
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.frame);
  }

  detach() {
    cancelAnimationFrame(this.raf);
    const c = this.canvas;
    if (c) {
      c.removeEventListener('pointerdown', this.onPointerDown);
      c.removeEventListener('pointermove', this.onPointerMove);
      c.removeEventListener('pointerleave', this.onPointerLeave);
    }
    if (this.shakeEl) this.shakeEl.style.transform = '';
    this.canvas = null;
    this.ctx = null;
    this.shakeEl = null;
  }

  resize() {
    const c = this.canvas;
    if (!c) return;
    const w = c.clientWidth;
    const h = c.clientHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (w === this.W && h === this.H && dpr === this.dpr && c.width > 0) return;
    this.W = w;
    this.H = h;
    this.dpr = dpr;
    c.width = Math.max(1, Math.round(w * dpr));
    c.height = Math.max(1, Math.round(h * dpr));
    // Don't reshuffle the menu backdrop for small changes (mobile URL bar).
    if (!this.deco.length || Math.abs(w - this.decoW) > 60 || Math.abs(h - this.decoH) > 140) this.initDeco();
    this.layout();
  }

  /** Screen rectangle (canvas-relative CSS px) the board may occupy. */
  setBoardArea(x: number, y: number, w: number, h: number) {
    this.area = { x, y, w, h };
    this.layout();
  }

  private layout() {
    if (!this.cols) return;
    const a = this.area.w > 0 ? this.area : { x: 0, y: 0, w: this.W, h: this.H };
    // Small early boards may use bigger cells so they don't look lost on large screens.
    const cap = this.cols <= 5 ? 96 : 78;
    const S = Math.max(16, Math.min((a.w - 12) / (this.cols + 0.62), (a.h - 18) / (this.rows + 0.8), cap));
    this.S = S;
    this.bx = a.x + (a.w - this.cols * S) / 2;
    this.by = a.y + (a.h - this.rows * S) / 2 - S * 0.06;
  }

  /* ---------------------------- commands -------------------------- */

  unlockAudio() {
    sfx.unlock();
  }

  /** Starts a fresh run from level 1. */
  start() {
    if (this.phase === 'gameover' && performance.now() < this.lockUntil) return;
    sfx.unlock();
    this.level = 1;
    this.score = 0;
    this.hearts = MAX_HEARTS;
    this.hints = MAX_HINTS;
    this.combo = 0;
    this.comboTimer = 0;
    this.bestCombo = 0;
    this.cleared = 0;
    this.result = null;
    this.final = null;
    this.particles.length = 0;
    this.popups.length = 0;
    this.gates.length = 0;
    this.shake = 0;
    this.phase = 'playing';
    this.buildLevel();
    sfx.start();
    this.emit();
  }

  nextLevel() {
    if (this.phase !== 'levelclear' || performance.now() < this.lockUntil) return;
    this.level++;
    this.result = null;
    this.phase = 'playing';
    this.buildLevel();
    sfx.click();
    this.emit();
  }

  pause() {
    if (this.phase !== 'playing' || this.locked) return;
    this.phase = 'paused';
    this.shake = 0;
    if (this.shakeEl) this.shakeEl.style.transform = '';
    this.emit();
  }

  resume() {
    if (this.phase !== 'paused') return;
    this.phase = 'playing';
    this.last = performance.now();
    sfx.click();
    this.emit();
  }

  toMenu() {
    if (this.phase === 'gameover' && performance.now() < this.lockUntil) return;
    this.phase = 'menu';
    this.arrows = [];
    this.byId.clear();
    this.cols = 0;
    this.rows = 0;
    this.particles.length = 0;
    this.popups.length = 0;
    this.gates.length = 0;
    this.result = null;
    this.final = null;
    this.score = 0;
    this.combo = 0;
    this.locked = false;
    this.pendingClear = -1;
    this.pendingOver = -1;
    sfx.click();
    this.emit();
  }

  toggleMute() {
    this.muted = !this.muted;
    sfx.setMuted(this.muted);
    saveSettings({ muted: this.muted, name: this.playerName });
    if (!this.muted) {
      sfx.unlock();
      sfx.click();
    }
    this.emit();
  }

  setPlayerName(name: string) {
    this.playerName = cleanName(name);
    saveSettings({ muted: this.muted, name: this.playerName });
    if (this.final && this.final.rank >= 0) this.scores = renameScore(this.final.entryId, this.playerName);
    this.emit();
  }

  useHint() {
    if (this.phase !== 'playing' || this.locked) return;
    if (this.hintId !== -1 && this.byId.get(this.hintId)?.state === IDLE) return;
    if (this.hints <= 0) {
      sfx.nope();
      return;
    }
    const id = this.findHint();
    if (id < 0) return;
    this.hints--;
    this.hintId = id;
    sfx.hint();
    this.emit();
  }

  /** Gameplay keys. Returns true when the key was consumed. */
  handleKey(key: string): boolean {
    if (this.phase !== 'playing') return false;
    switch (key) {
      case 'ArrowUp':
      case 'w':
      case 'W':
        this.moveCursor(0, -1);
        return true;
      case 'ArrowDown':
      case 's':
      case 'S':
        this.moveCursor(0, 1);
        return true;
      case 'ArrowLeft':
      case 'a':
      case 'A':
        this.moveCursor(-1, 0);
        return true;
      case 'ArrowRight':
      case 'd':
      case 'D':
        this.moveCursor(1, 0);
        return true;
      case ' ':
      case 'Spacebar':
      case 'Enter': {
        if (this.locked) return true;
        this.keyboard = true;
        const id = this.occ[this.cursorY * this.cols + this.cursorX];
        if (id >= 0) this.tap(id);
        else sfx.nope();
        return true;
      }
      case 'h':
      case 'H':
        this.useHint();
        return true;
      default:
        return false;
    }
  }

  private moveCursor(dx: number, dy: number) {
    if (this.locked || !this.cols) return;
    const wasOn = this.keyboard;
    this.keyboard = true;
    this.hoverId = -1;
    if (!wasOn) {
      // First key press just reveals the cursor where it already is.
      sfx.move();
      return;
    }
    const nx = Math.min(this.cols - 1, Math.max(0, this.cursorX + dx));
    const ny = Math.min(this.rows - 1, Math.max(0, this.cursorY + dy));
    if (nx !== this.cursorX || ny !== this.cursorY) {
      this.cursorX = nx;
      this.cursorY = ny;
      sfx.move();
    }
  }

  /* ----------------------------- input ---------------------------- */

  private onPointerDown = (e: PointerEvent) => {
    if (e.button > 0) return;
    sfx.unlock();
    if (this.phase !== 'playing' || !this.canvas) return;
    e.preventDefault();
    this.keyboard = false;
    const r = this.canvas.getBoundingClientRect();
    const id = this.pick(e.clientX - r.left, e.clientY - r.top);
    if (id >= 0) this.tap(id);
  };

  private onPointerMove = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse' || !this.canvas) return;
    let id = -1;
    if (this.phase === 'playing' && !this.locked) {
      const r = this.canvas.getBoundingClientRect();
      id = this.pick(e.clientX - r.left, e.clientY - r.top);
      if (id >= 0 && this.byId.get(id)?.state !== IDLE) id = -1;
    }
    if (id !== this.hoverId) {
      this.hoverId = id;
      this.canvas.style.cursor = id >= 0 ? 'pointer' : '';
    }
  };

  private onPointerLeave = () => {
    this.hoverId = -1;
  };

  /** Arrow under a point, with a little forgiveness around each cell. */
  private pick(px: number, py: number): number {
    if (!this.cols) return -1;
    const fx = (px - this.bx) / this.S;
    const fy = (py - this.by) / this.S;
    const cx = Math.floor(fx);
    const cy = Math.floor(fy);
    if (cx >= 0 && cy >= 0 && cx < this.cols && cy < this.rows) {
      const id = this.occ[cy * this.cols + cx];
      if (id >= 0) return id;
    }
    let best = -1;
    let bestD = 0.85 * 0.85;
    for (let y = cy - 1; y <= cy + 1; y++) {
      for (let x = cx - 1; x <= cx + 1; x++) {
        if (x < 0 || y < 0 || x >= this.cols || y >= this.rows) continue;
        const id = this.occ[y * this.cols + x];
        if (id < 0) continue;
        const d = (fx - x - 0.5) ** 2 + (fy - y - 0.5) ** 2;
        if (d < bestD) {
          bestD = d;
          best = id;
        }
      }
    }
    return best;
  }

  /* --------------------------- level setup ------------------------ */

  private buildLevel() {
    // Short, wide play areas (phones held sideways) get landscape boards.
    const area = this.area.w > 0 ? this.area : { w: this.W, h: this.H };
    const wide = area.h < 440 && area.w > area.h * 1.2;
    const def = generateLevel(this.level, Math.random, wide);
    const { cols, rows } = def;
    const firstBoard = this.cols === 0;
    this.cols = cols;
    this.rows = rows;
    this.bumpers = def.bumpers;
    this.bumperPulse = new Float32Array(cols * rows);
    this.occ = new Int16Array(cols * rows).fill(-1);
    this.arrows = [];
    this.byId.clear();

    for (const d of def.arrows) {
      const head = d.cells[d.cells.length - 1];
      const nodes: number[] = [];
      let cx = 0;
      let cy = 0;
      for (const c of d.cells) {
        this.occ[c.y * cols + c.x] = d.id;
        nodes.push(c.x + 0.5, c.y + 0.5);
        cx += c.x + 0.5;
        cy += c.y + 0.5;
      }
      nodes.push(head.x + 0.5 + DX[d.dir], head.y + 0.5 + DY[d.dir]);
      const shape = buildShape(nodes, d.cells.length, 0);
      const a: Arrow = {
        id: d.id,
        cells: d.cells,
        dir: d.dir,
        len: d.cells.length,
        frost: d.frost,
        fuse: d.fuse,
        bomb: d.fuse > 0,
        rank: d.rank,
        ray: geometricRay(cols, rows, def.bumpers, head, d.dir),
        state: IDLE,
        body: shape.body,
        head: shape.head,
        cx: cx / d.cells.length,
        cy: cy / d.cells.length,
        tx: d.cells[0].x + 0.5,
        ty: d.cells[0].y + 0.5,
        spawnDelay: 0.08 + (head.x + head.y) * 0.032 + Math.random() * 0.05,
        spawn: 0,
        nodes,
        t: 0,
        v: 0,
        pathLen: 0,
        turnNodes: [],
        turnCells: [],
        turnDone: 0,
        exitDir: d.dir,
        burst: false,
        alpha: 1,
        bumpT: 0,
        bumpMax: 0,
        bumpDur1: 0,
        bumpHit: false,
        blocker: -1,
        hit: 0,
        hitDir: 0,
        wobble: 0,
        badgePop: 0,
        ox: 0,
        oy: 0,
        vx: 0,
        vy: 0,
        rot: 0,
        vr: 0,
      };
      this.arrows.push(a);
      this.byId.set(a.id, a);
    }

    this.total = this.remaining = def.arrows.length;
    this.mistakes = 0;
    this.levelTime = 0;
    this.idle = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.locked = false;
    this.pendingClear = -1;
    this.pendingOver = -1;
    this.hoverId = -1;
    this.hintId = this.level === 1 ? this.findHint() : -1;
    this.boardPop = 0;
    if (firstBoard) {
      this.cursorX = cols >> 1;
      this.cursorY = rows >> 1;
    }
    this.cursorX = Math.min(this.cursorX, cols - 1);
    this.cursorY = Math.min(this.cursorY, rows - 1);
    this.layout();
    if (this.level > 1) this.callout(`LEVEL ${this.level}`, '#FFFFFF');
  }

  private findHint(): number {
    const list: SolverArrow[] = [];
    for (const a of this.arrows) {
      if (a.state === IDLE || a.state === BUMP) {
        list.push({ id: a.id, ray: a.ray, frost: a.frost, fuse: a.fuse, rank: a.rank });
      }
    }
    return suggestMove(this.occ, list);
  }

  /* ----------------------------- moves ---------------------------- */

  private tap(id: number) {
    if (this.phase !== 'playing' || this.locked) return;
    const a = this.byId.get(id);
    if (!a || a.state !== IDLE || a.spawnDelay > 0.12) return;
    a.spawn = 1;
    a.spawnDelay = 0;
    this.hintId = -1;
    this.idle = 0;
    if (a.frost > 0) {
      a.wobble = 1;
      sfx.frozen();
      this.popup(a.cx, a.cy - 0.35, a.frost === 1 ? 'THAWS IN 1' : `THAWS IN ${a.frost}`, '#8FD3FF', 0.36, 0.9);
      return;
    }
    const head = a.cells[a.len - 1];
    const tr = tracePath(this.cols, this.rows, this.occ, this.bumpers, head, a.dir);
    if (tr.blockedBy === -1) this.launch(a, tr);
    else this.bump(a, tr);
  }

  private pathNodes(a: Arrow, tr: Trace, extra: number): number[] {
    const nodes: number[] = [];
    for (const c of a.cells) nodes.push(c.x + 0.5, c.y + 0.5);
    for (const c of tr.path) nodes.push(c.x + 0.5, c.y + 0.5);
    const lx = nodes[nodes.length - 2];
    const ly = nodes[nodes.length - 1];
    for (let j = 1; j <= extra; j++) nodes.push(lx + DX[tr.exitDir] * j, ly + DY[tr.exitDir] * j);
    return nodes;
  }

  private launch(a: Arrow, tr: Trace) {
    const cols = this.cols;
    for (const c of a.cells) this.occ[c.y * cols + c.x] = -1;
    a.nodes = this.pathNodes(a, tr, a.len + 4);
    a.state = EXIT;
    a.t = 0;
    a.v = 11;
    a.alpha = 1;
    a.pathLen = tr.path.length;
    a.turnNodes = tr.turns.map((i) => a.len + i);
    a.turnCells = tr.turns.map((i) => tr.path[i].y * cols + tr.path[i].x);
    a.turnDone = 0;
    a.exitDir = tr.exitDir;
    a.burst = false;

    this.combo = this.combo > 0 ? this.combo + 1 : 1;
    this.comboTimer = COMBO_WINDOW;
    this.comboKey++;
    if (this.combo > this.bestCombo) this.bestCombo = this.combo;
    const pts = 100 * Math.min(this.combo, 10);
    this.score += pts;
    this.remaining--;
    this.cleared++;

    const head = a.cells[a.len - 1];
    const pal = PALETTE[a.dir];
    this.popup(head.x + 0.5, head.y + 0.2, `+${pts}`, this.combo > 1 ? '#FFE066' : '#FFFFFF', this.combo > 1 ? 0.5 : 0.42, 0.8);
    if (a.bomb) {
      this.score += 300;
      this.popup(a.tx, a.ty - 0.3, 'DEFUSED +300', '#7CF0B4', 0.38, 1.1);
      sfx.defuse();
    }
    if (this.combo === 5) this.callout('NICE!');
    else if (this.combo === 8) this.callout('ON FIRE!');
    else if (this.combo === 12) this.callout('UNSTOPPABLE!');
    sfx.launch(this.combo);
    this.kick = 1;

    // Kick-off puff where the tail was.
    const [px, py] = this.toPx(a.tx, a.ty);
    this.ring(px, py, this.S * 0.55, pal.light, 0.3);
    for (let i = 0; i < 5; i++) {
      const ang = Math.random() * Math.PI * 2;
      this.spawn(1, px, py, Math.cos(ang) * rnd(30, 110), Math.sin(ang) * rnd(30, 110), rnd(0.25, 0.45), this.S * rnd(0.06, 0.12), pal.light, 0, 4);
    }

    this.tickOthers(a, true);
    if (this.remaining === 0 && this.hearts > 0) this.beginClear();
    this.emit();
  }

  private bump(a: Arrow, tr: Trace) {
    const cols = this.cols;
    a.nodes = this.pathNodes(a, tr, 1);
    a.state = BUMP;
    a.t = 0;
    a.bumpT = 0;
    a.pathLen = tr.path.length;
    a.bumpMax = a.pathLen + 0.3;
    a.bumpDur1 = 0.075 + 0.026 * a.pathLen;
    a.bumpHit = false;
    a.blocker = tr.blockedBy;
    a.exitDir = tr.exitDir;
    a.turnNodes = tr.turns.map((i) => a.len + i);
    a.turnCells = tr.turns.map((i) => tr.path[i].y * cols + tr.path[i].x);
    a.turnDone = 0;
  }

  private impact(a: Arrow) {
    const blocker = this.byId.get(a.blocker);
    if (blocker && (blocker.state === IDLE || blocker.state === BUMP)) {
      blocker.hit = 1;
      blocker.hitDir = a.exitDir;
    }
    samplePath(a.nodes, a.bumpMax + a.len - 1);
    const cxU = sx + DX[a.exitDir] * HEAD_TIP;
    const cyU = sy + DY[a.exitDir] * HEAD_TIP;
    const [px, py] = this.toPx(cxU, cyU);
    const S = this.S;
    for (let i = 0; i < 12; i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = rnd(120, 420) * (S / 48);
      this.spawn(2, px, py, Math.cos(ang) * sp, Math.sin(ang) * sp, rnd(0.18, 0.36), S * 0.07, i % 2 ? DANGER : '#FFD166', 0, 5);
    }
    this.ring(px, py, S * 0.8, DANGER, 0.32);
    this.popup(cxU, cyU - 0.35, 'BLOCKED!', '#FF6B7F', 0.46, 0.9);
    this.addShake(10);
    sfx.blocked();
    buzz(60);
    this.loseHeart();
    this.emit();
  }

  private loseHeart() {
    this.hearts = Math.max(0, this.hearts - 1);
    this.mistakes++;
    this.combo = 0;
    this.comboTimer = 0;
    this.hurtKey++;
    if (this.hearts <= 0 && this.pendingOver < 0) this.beginGameOver();
  }

  /** Every escape ticks frost (and, for real moves, bomb fuses) on the rest. */
  private tickOthers(source: Arrow, isMove: boolean) {
    const blown: Arrow[] = [];
    let frostTick = false;
    let fuseTick = 0;
    for (const o of this.arrows) {
      if (o === source || (o.state !== IDLE && o.state !== BUMP)) continue;
      if (o.frost > 0) {
        o.frost--;
        o.badgePop = 1;
        if (o.frost === 0) this.thaw(o);
        else frostTick = true;
      }
      if (isMove && o.fuse > 0) {
        o.fuse--;
        o.badgePop = 1;
        if (o.fuse === 0) blown.push(o);
        else fuseTick = Math.max(fuseTick, o.fuse <= 2 ? 2 : 1);
      }
    }
    if (frostTick) sfx.frostTick();
    if (fuseTick) sfx.fuseTick(fuseTick === 2);
    for (const b of blown) this.explode(b);
  }

  private thaw(a: Arrow) {
    const S = this.S;
    for (const c of a.cells) {
      const [px, py] = this.toPx(c.x + 0.5, c.y + 0.5);
      for (let i = 0; i < 4; i++) {
        const ang = Math.random() * Math.PI * 2;
        const sp = rnd(60, 220) * (S / 48);
        this.spawn(4, px, py, Math.cos(ang) * sp, Math.sin(ang) * sp - 60, rnd(0.4, 0.7), S * rnd(0.1, 0.18), i % 2 ? '#DDF3FF' : '#9FD8FF', 700, 1.5, Math.random() * 6, rnd(-9, 9));
      }
    }
    this.popup(a.cx, a.cy - 0.3, 'THAWED!', '#8FD3FF', 0.4, 0.9);
    sfx.thaw();
  }

  private explode(b: Arrow) {
    const S = this.S;
    for (const c of b.cells) {
      this.occ[c.y * this.cols + c.x] = -1;
      const [px, py] = this.toPx(c.x + 0.5, c.y + 0.5);
      for (let i = 0; i < 7; i++) {
        const ang = Math.random() * Math.PI * 2;
        const sp = rnd(120, 520) * (S / 48);
        const col = i % 3 === 0 ? '#FFD166' : i % 3 === 1 ? DANGER : BOMB_BODY;
        this.spawn(i % 2 ? 4 : 1, px, py, Math.cos(ang) * sp, Math.sin(ang) * sp - 80, rnd(0.45, 0.9), S * rnd(0.1, 0.22), col, 900, 1.2, Math.random() * 6, rnd(-10, 10));
      }
      this.ring(px, py, S * 1.1, '#FFD166', 0.4);
    }
    b.state = DEAD;
    this.remaining--;
    if (this.hintId === b.id) this.hintId = -1;
    this.popup(b.cx, b.cy - 0.2, 'BOOM!', '#FF6B7F', 0.62, 1.1);
    this.addShake(18);
    sfx.explode();
    buzz([40, 30, 90]);
    this.loseHeart();
    this.tickOthers(b, false);
    if (this.remaining === 0 && this.hearts > 0) this.beginClear();
  }

  /* ------------------------- end of level ------------------------- */

  private beginClear() {
    if (this.pendingClear >= 0) return;
    this.locked = true;
    this.pendingClear = 0.8;
    this.hintId = -1;
    sfx.levelClear();
    const S = this.S;
    const cx = this.bx + (this.cols * S) / 2;
    const cy = this.by + (this.rows * S) / 2;
    const n = this.reduceMotion ? 30 : 90;
    for (let i = 0; i < n; i++) {
      const ang = -Math.PI / 2 + rnd(-1.25, 1.25);
      const sp = rnd(260, 900) * Math.max(0.8, S / 56);
      const pal = PALETTE[i % 4];
      this.spawn(i % 5 === 0 ? 4 : 0, cx + rnd(-S, S), cy + rnd(-S * 0.5, S * 0.5), Math.cos(ang) * sp, Math.sin(ang) * sp, rnd(1.1, 2), rnd(7, 13), i % 3 ? pal.fill : pal.light, 1300, 1.1, Math.random() * 6, rnd(-12, 12));
    }
    this.ring(cx, cy, Math.max(this.cols, this.rows) * S * 0.75, '#FFE066', 0.6);
  }

  private finishLevel() {
    const par = this.total * 2.5 + 6;
    const timeBonus = Math.max(0, Math.round(((par - this.levelTime) * 20) / 10) * 10);
    const clearBonus = 300 + 100 * this.level;
    const perfectBonus = this.mistakes === 0 ? 500 : 0;
    const total = clearBonus + timeBonus + perfectBonus;
    const healed = this.hearts < MAX_HEARTS;
    if (healed) this.hearts++;
    this.hints = Math.min(MAX_HINTS, this.hints + 1);
    this.score += total;
    this.combo = 0;
    this.result = {
      level: this.level,
      seconds: this.levelTime,
      mistakes: this.mistakes,
      stars: this.mistakes === 0 ? 3 : this.mistakes === 1 ? 2 : 1,
      clearBonus,
      timeBonus,
      perfectBonus,
      total,
      healed,
    };
    this.phase = 'levelclear';
    this.lockUntil = performance.now() + 450;
    this.emit();
  }

  private beginGameOver() {
    this.locked = true;
    this.pendingOver = 1.15;
    this.pendingClear = -1;
    this.hintId = -1;
    this.hoverId = -1;
    sfx.gameOver();
    buzz([80, 40, 140]);
    this.addShake(16);
    for (const a of this.arrows) {
      if (a.state !== IDLE && a.state !== BUMP) continue;
      if (a.state === BUMP) {
        // Snap back to rest so the cached idle shape lines up before it falls.
        a.t = 0;
      }
      a.state = FALL;
      a.spawn = 1;
      a.ox = 0;
      a.oy = 0;
      a.vx = rnd(-5, 5);
      a.vy = rnd(-13, -6);
      a.rot = 0;
      a.vr = rnd(-7, 7);
      a.t = -rnd(0, 0.18); // staggered release
      a.alpha = 1;
    }
  }

  private finishGameOver() {
    const { list, rank, id } = addScore(this.playerName, this.score, this.level);
    this.scores = list;
    this.final = {
      score: this.score,
      level: this.level,
      cleared: this.cleared,
      bestCombo: this.bestCombo,
      rank,
      entryId: id,
    };
    this.phase = 'gameover';
    this.lockUntil = performance.now() + 650;
    this.emit();
  }

  /* ---------------------------- effects --------------------------- */

  private toPx(ux: number, uy: number): [number, number] {
    return [this.bx + ux * this.S, this.by + uy * this.S];
  }

  private addShake(amount: number) {
    this.shake = Math.max(this.shake, amount * (this.reduceMotion ? 0.25 : 1));
  }

  private spawn(
    kind: number,
    x: number,
    y: number,
    vx: number,
    vy: number,
    life: number,
    size: number,
    color: string,
    g = 0,
    drag = 0,
    rot = 0,
    vr = 0,
  ) {
    if (this.particles.length >= 520) return;
    this.particles.push({ kind, x, y, vx, vy, g, drag, age: 0, life, size, rot, vr, color });
  }

  private ring(x: number, y: number, radius: number, color: string, life: number) {
    this.spawn(3, x, y, 0, 0, life, radius, color);
  }

  /** Floating text at a board position (cell units). `size` is in cells. */
  private popup(ux: number, uy: number, text: string, color: string, size: number, life: number) {
    const [x, y] = this.toPx(ux, uy);
    const px = Math.max(15, Math.min(40, size * this.S));
    const margin = text.length * px * 0.3 + 8;
    this.popups.push({
      x: Math.min(this.W - margin, Math.max(margin, x)),
      y: Math.max(px, y),
      text,
      color,
      size: px,
      age: 0,
      life,
      rise: this.S * 0.9,
    });
    if (this.popups.length > 24) this.popups.shift();
  }

  private callout(text: string, color = '#FFE066') {
    const size = Math.max(26, Math.min(54, this.S * 0.8));
    this.popups.push({
      x: this.bx + (this.cols * this.S) / 2,
      y: this.by + (this.rows * this.S) / 2,
      text,
      color,
      size,
      age: 0,
      life: 1.2,
      rise: this.S * 0.6,
    });
  }

  private exitBurst(a: Arrow) {
    const S = this.S;
    const last = a.len - 1 + a.pathLen;
    const dx = DX[a.exitDir];
    const dy = DY[a.exitDir];
    const ex = this.bx + (a.nodes[2 * last] + dx * 0.5) * S + dx * S * 0.3;
    const ey = this.by + (a.nodes[2 * last + 1] + dy * 0.5) * S + dy * S * 0.3;
    const pal = PALETTE[a.dir];
    const base = Math.atan2(dy, dx);
    const k = S / 48;
    const n = this.reduceMotion ? 5 : 11;
    for (let i = 0; i < n; i++) {
      const ang = base + rnd(-0.75, 0.75);
      const sp = rnd(160, 560) * k;
      this.spawn(i % 4 === 3 ? 1 : 0, ex, ey, Math.cos(ang) * sp, Math.sin(ang) * sp, rnd(0.45, 0.85), rnd(5, 9) * Math.max(0.8, k), i % 3 === 0 ? pal.light : i % 3 === 1 ? pal.fill : '#FFFFFF', 950, 1.6, Math.random() * 6, rnd(-14, 14));
    }
    for (let i = 0; i < 4; i++) {
      const ang = base + rnd(-0.35, 0.35);
      const sp = rnd(420, 760) * k;
      this.spawn(2, ex, ey, Math.cos(ang) * sp, Math.sin(ang) * sp, rnd(0.14, 0.26), S * 0.06, pal.light, 0, 3);
    }
    this.ring(ex, ey, S * 0.7, pal.fill, 0.3);
    this.gates.push({ x: ex, y: ey, horizontal: dy !== 0, color: pal.fill, age: 0 });
    this.addShake(1.2 + Math.min(this.combo, 8) * 0.3);
    sfx.exit();
  }

  private pingBumper(cell: number) {
    this.bumperPulse[cell] = 1;
    const x = cell % this.cols;
    const y = (cell - x) / this.cols;
    const [px, py] = this.toPx(x + 0.5, y + 0.5);
    for (let i = 0; i < 6; i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = rnd(90, 260) * (this.S / 48);
      this.spawn(2, px, py, Math.cos(ang) * sp, Math.sin(ang) * sp, rnd(0.16, 0.3), this.S * 0.06, i % 2 ? BUMPER_LIGHT : '#FFFFFF', 0, 4);
    }
    sfx.bumper();
  }

  private initDeco() {
    const { W, H } = this;
    if (!W || !H) return;
    this.decoW = W;
    this.decoH = H;
    const count = Math.max(9, Math.min(24, Math.round((W * H) / 42000)));
    this.deco = [];
    for (let i = 0; i < count; i++) {
      const dir = (i % 4) as Dir;
      const len = 2 + Math.floor(Math.random() * 4);
      // Random snake grown backwards from the head at the origin.
      const cells: Cell[] = [{ x: 0, y: 0 }];
      let gd = ((dir + 2) % 4) as Dir;
      let x = 0;
      let y = 0;
      for (let k = 1; k < len; k++) {
        if (k > 1 && Math.random() < 0.4) {
          const turn = ((gd + (Math.random() < 0.5 ? 1 : 3)) % 4) as Dir;
          if (turn !== dir) gd = turn; // never curl back in front of the head
        }
        x += DX[gd];
        y += DY[gd];
        if (cells.some((c) => c.x === x && c.y === y)) break;
        cells.push({ x, y });
      }
      cells.reverse();
      const nodes: number[] = [];
      for (const c of cells) nodes.push(c.x, c.y);
      nodes.push(DX[dir], DY[dir]);
      const shape = buildShape(nodes, cells.length, 0);
      const s = rnd(30, 70) * Math.max(0.75, Math.min(1.15, Math.min(W, H) / 640));
      this.deco.push({
        x: Math.random() * W,
        y: Math.random() * H,
        s,
        dir,
        speed: rnd(22, 52) * (s / 44),
        reach: s * (cells.length + 1.2),
        body: shape.body,
        head: shape.head,
      });
    }
    this.deco.sort((a, b) => a.s - b.s);
  }

  /* ----------------------------- update --------------------------- */

  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    if (dt < 0) dt = 0;
    if (this.phase !== 'paused') this.update(dt);
    this.render();
  };

  private update(dt: number) {
    this.time += dt;

    if (this.phase === 'menu') {
      const { W, H } = this;
      for (const d of this.deco) {
        d.x += DX[d.dir] * d.speed * dt;
        d.y += DY[d.dir] * d.speed * dt;
        if (d.x > W + d.reach) d.x = -d.reach;
        else if (d.x < -d.reach) d.x = W + d.reach;
        if (d.y > H + d.reach) d.y = -d.reach;
        else if (d.y < -d.reach) d.y = H + d.reach;
      }
    }

    if (this.phase === 'playing' && !this.locked) {
      this.levelTime += dt;
      // New players who hesitate on the first boards get a free nudge.
      this.idle += dt;
      if (this.level <= 2 && this.idle > 7 && this.hintId === -1 && this.remaining > 0) {
        this.hintId = this.findHint();
        this.idle = 0;
      }
      if (this.combo > 0) {
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) {
          this.combo = 0;
          this.emit();
        }
      }
    }

    if (this.boardPop < 1) this.boardPop = Math.min(1, this.boardPop + dt / 0.42);
    if (this.kick > 0) this.kick = Math.max(0, this.kick - dt / 0.2);

    let dead = false;
    for (const a of this.arrows) {
      this.updateArrow(a, dt);
      if (a.state === DEAD) dead = true;
    }
    if (dead) {
      this.arrows = this.arrows.filter((a) => a.state !== DEAD);
    }

    const bp = this.bumperPulse;
    for (let i = 0; i < bp.length; i++) if (bp[i] > 0) bp[i] = Math.max(0, bp[i] - dt / 0.35);

    // Particles
    const ps = this.particles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.age += dt;
      if (p.age >= p.life) {
        ps[i] = ps[ps.length - 1];
        ps.pop();
        continue;
      }
      p.vy += p.g * dt;
      if (p.drag) {
        const d = Math.exp(-p.drag * dt);
        p.vx *= d;
        p.vy *= d;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const p = this.popups[i];
      p.age += dt;
      if (p.age >= p.life) this.popups.splice(i, 1);
    }
    for (let i = this.gates.length - 1; i >= 0; i--) {
      const g = this.gates[i];
      g.age += dt;
      if (g.age >= 0.36) this.gates.splice(i, 1);
    }

    // Screen shake drives the wrapper element directly (compositor-only).
    if (this.shakeEl) {
      if (this.shake > 0.35) {
        const m = this.shake;
        this.shakeEl.style.transform = `translate3d(${Math.round((Math.random() * 2 - 1) * m)}px,${Math.round((Math.random() * 2 - 1) * m)}px,0)`;
        this.shake *= Math.exp(-dt * 9);
      } else if (this.shake !== 0) {
        this.shake = 0;
        this.shakeEl.style.transform = '';
      }
    }

    if (this.pendingOver >= 0) {
      this.pendingOver -= dt;
      if (this.pendingOver < 0) this.finishGameOver();
    } else if (this.pendingClear >= 0) {
      this.pendingClear -= dt;
      if (this.pendingClear < 0) this.finishLevel();
    }
  }

  private updateArrow(a: Arrow, dt: number) {
    if (a.spawn < 1) {
      if (a.spawnDelay > 0) a.spawnDelay -= dt;
      else a.spawn = Math.min(1, a.spawn + dt / 0.34);
    }
    if (a.hit > 0) a.hit = Math.max(0, a.hit - dt / 0.42);
    if (a.wobble > 0) a.wobble = Math.max(0, a.wobble - dt / 0.45);
    if (a.badgePop > 0) a.badgePop = Math.max(0, a.badgePop - dt / 0.3);

    if (a.state === EXIT) {
      a.v += 150 * dt;
      a.t += a.v * dt;
      const headS = a.t + a.len - 1;
      while (a.turnDone < a.turnNodes.length && headS >= a.turnNodes[a.turnDone]) {
        this.pingBumper(a.turnCells[a.turnDone]);
        a.turnDone++;
      }
      if (!a.burst && a.t >= a.pathLen + 0.15) {
        a.burst = true;
        this.exitBurst(a);
      }
      // Trail from the tail while it is still on the board.
      if (a.t < a.pathLen + a.len && Math.random() < dt * 70) {
        samplePath(a.nodes, a.t);
        const [px, py] = this.toPx(sx, sy);
        const pal = PALETTE[a.dir];
        this.spawn(1, px + rnd(-3, 3), py + rnd(-3, 3), rnd(-20, 20), rnd(-20, 20), rnd(0.22, 0.4), this.S * rnd(0.07, 0.13), Math.random() < 0.5 ? pal.light : '#FFFFFF', 0, 2);
      }
      const fadeStart = a.pathLen + 0.6;
      const end = a.pathLen + a.len + 2.4;
      a.alpha = 1 - clamp01((a.t - fadeStart) / (end - fadeStart)) ** 2;
      if (a.t >= end) a.state = DEAD;
    } else if (a.state === BUMP) {
      a.bumpT += dt;
      if (a.bumpT < a.bumpDur1) {
        const k = a.bumpT / a.bumpDur1;
        a.t = a.bumpMax * k * k;
        const headS = a.t + a.len - 1;
        while (a.turnDone < a.turnNodes.length && headS >= a.turnNodes[a.turnDone]) {
          this.pingBumper(a.turnCells[a.turnDone]);
          a.turnDone++;
        }
      } else {
        if (!a.bumpHit) {
          a.bumpHit = true;
          a.t = a.bumpMax;
          this.impact(a);
          if (a.state !== BUMP) return; // the hit ended the run and released the board
        }
        const k = Math.min(1, (a.bumpT - a.bumpDur1) / 0.26);
        a.t = a.bumpMax * (1 - easeOutCubic(k));
        if (k >= 1) {
          a.t = 0;
          a.state = IDLE;
        }
      }
    } else if (a.state === FALL) {
      if (a.t < 0) {
        a.t += dt;
        return;
      }
      a.vy += 46 * dt;
      a.ox += a.vx * dt;
      a.oy += a.vy * dt;
      a.rot += a.vr * dt;
      a.t += dt;
      if (a.t > 0.75) a.alpha = Math.max(0, 1 - (a.t - 0.75) / 0.35);
      if (a.t > 1.1) a.state = DEAD;
    }
  }

  /* ----------------------------- render --------------------------- */

  private render() {
    const ctx = this.ctx;
    if (!ctx) return;
    const { W, H, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    if (this.phase === 'menu') {
      this.drawDeco(ctx);
      return;
    }
    if (!this.cols) return;
    this.drawBoard(ctx);
    if (this.phase === 'paused') return;
    this.drawGates(ctx);
    this.drawParticles(ctx);
    this.drawPopups(ctx);
  }

  private paintArrow(
    ctx: CanvasRenderingContext2D,
    body: Path2D,
    head: Path2D,
    dir: Dir,
    bomb: boolean,
    frozen: boolean,
    tint: string | null,
  ) {
    const pal = PALETTE[dir];
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Hard drop shadow
    ctx.save();
    ctx.translate(0, 0.075);
    ctx.strokeStyle = DROP;
    ctx.fillStyle = DROP;
    ctx.lineWidth = BODY_W + OUTLINE * 2;
    ctx.stroke(body);
    ctx.lineWidth = HEAD_ROUND + OUTLINE * 2;
    ctx.stroke(head);
    ctx.fill(head);
    ctx.restore();

    // Ink outline
    ctx.strokeStyle = frozen ? FROST_OUTLINE : INK;
    ctx.lineWidth = BODY_W + OUTLINE * 2;
    ctx.stroke(body);
    ctx.lineWidth = HEAD_ROUND + OUTLINE * 2;
    ctx.stroke(head);

    // Body + sheen
    ctx.strokeStyle = bomb ? BOMB_BODY : pal.fill;
    ctx.lineWidth = BODY_W;
    ctx.stroke(body);
    ctx.save();
    ctx.translate(-0.04, -0.05);
    ctx.strokeStyle = bomb ? BOMB_LIGHT : pal.light;
    ctx.lineWidth = 0.07;
    ctx.stroke(body);
    ctx.restore();

    // Head
    ctx.fillStyle = pal.fill;
    ctx.strokeStyle = pal.fill;
    ctx.lineWidth = HEAD_ROUND;
    ctx.fill(head);
    ctx.stroke(head);

    if (frozen) {
      const ice = 'rgba(226,245,255,0.6)';
      ctx.strokeStyle = ice;
      ctx.fillStyle = ice;
      ctx.lineWidth = BODY_W;
      ctx.stroke(body);
      ctx.lineWidth = HEAD_ROUND;
      ctx.fill(head);
      ctx.stroke(head);
      ctx.save();
      ctx.translate(-0.04, -0.05);
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 0.07;
      ctx.stroke(body);
      ctx.restore();
    }
    if (tint) {
      ctx.strokeStyle = tint;
      ctx.fillStyle = tint;
      ctx.lineWidth = BODY_W;
      ctx.stroke(body);
      ctx.lineWidth = HEAD_ROUND;
      ctx.fill(head);
      ctx.stroke(head);
    }
  }

  /** Text inside cell-unit space, drawn at a nominal size so tiny font sizes never get clamped. */
  private unitText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, size: number, color: string) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(1 / 64, 1 / 64);
    ctx.font = `${Math.round(size * 64)}px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = color;
    ctx.fillText(text, 0, 2);
    ctx.restore();
  }

  private drawArrow(ctx: CanvasRenderingContext2D, a: Arrow, highlight: boolean) {
    let body = a.body;
    let head = a.head;
    let alpha = 1;
    ctx.save();

    if (a.state === EXIT || a.state === BUMP) {
      const sh = buildShape(a.nodes, a.len, a.t);
      body = sh.body;
      head = sh.head;
      if (a.state === EXIT) alpha = a.alpha;
    } else {
      let sc = 1;
      let rot = 0;
      let ox = 0;
      let oy = 0;
      if (a.spawn < 1) {
        if (a.spawn <= 0) {
          ctx.restore();
          return;
        }
        sc = Math.max(0.01, easeOutBack(a.spawn));
      } else if (a.state === IDLE) {
        // A slow diagonal ripple keeps the board feeling alive.
        const w = Math.sin(this.time * 1.5 - (a.cx + a.cy) * 0.5);
        if (w > 0.9) sc = 1 + (w - 0.9) * 0.45;
        if (highlight) sc *= 1.07;
      }
      if (a.hit > 0) {
        const p = Math.sin(a.hit * Math.PI) * 0.1;
        ox = DX[a.hitDir] * p;
        oy = DY[a.hitDir] * p;
      }
      if (a.wobble > 0) rot = Math.sin(this.time * 46) * 0.075 * a.wobble;
      if (a.state === FALL) {
        ox = a.ox;
        oy = a.oy;
        rot = a.rot;
        alpha = a.alpha;
      }
      if (sc !== 1 || rot !== 0 || ox !== 0 || oy !== 0) {
        ctx.translate(a.cx + ox, a.cy + oy);
        if (rot) ctx.rotate(rot);
        if (sc !== 1) ctx.scale(sc, sc);
        ctx.translate(-a.cx, -a.cy);
      }
    }
    if (alpha <= 0.01) {
      ctx.restore();
      return;
    }
    if (alpha < 1) ctx.globalAlpha = alpha;

    let tint: string | null = null;
    if (a.hit > 0) tint = `rgba(255,60,90,${(0.75 * a.hit).toFixed(3)})`;
    else if (a.bomb && a.fuse > 0 && a.fuse <= 2 && a.state === IDLE) {
      tint = `rgba(255,60,90,${(0.22 + 0.22 * Math.sin(this.time * 12)).toFixed(3)})`;
    } else if (highlight && a.state === IDLE) tint = 'rgba(255,255,255,0.24)';

    const frozen = a.frost > 0;
    this.paintArrow(ctx, body, head, a.dir, a.bomb, frozen, tint);

    // Counter badge on the tail (frost / fuse).
    if ((frozen || (a.bomb && a.fuse > 0)) && (a.state === IDLE || a.state === FALL)) {
      const pop = 1 + 0.5 * Math.sin(a.badgePop * Math.PI);
      const urgent = a.bomb && a.fuse <= 2;
      const beat = urgent ? 1 + 0.08 * Math.sin(this.time * 12) : 1;
      const r = 0.25 * pop * beat;
      ctx.beginPath();
      ctx.arc(a.tx, a.ty, r, 0, Math.PI * 2);
      ctx.fillStyle = frozen ? '#E6F6FF' : DANGER;
      ctx.fill();
      ctx.lineWidth = 0.05;
      ctx.strokeStyle = frozen ? FROST_OUTLINE : INK;
      ctx.stroke();
      this.unitText(ctx, String(frozen ? a.frost : a.fuse), a.tx, a.ty, 0.34 * pop * beat, frozen ? FROST_OUTLINE : '#FFFFFF');
    }
    ctx.restore();
  }

  private drawBoard(ctx: CanvasRenderingContext2D) {
    const { S, bx, by, cols, rows } = this;
    const bw = cols * S;
    const bh = rows * S;
    ctx.save();

    // Pop-in when a level starts, plus a tiny recoil every time an arrow launches.
    const recoil = this.reduceMotion ? 0 : 0.014 * Math.sin(this.kick * Math.PI);
    const k = (0.9 + 0.1 * easeOutBack(this.boardPop)) * (1 - recoil);
    if (Math.abs(k - 1) > 1e-4) {
      const cx = bx + bw / 2;
      const cy = by + bh / 2;
      ctx.translate(cx, cy);
      ctx.scale(k, k);
      ctx.translate(-cx, -cy);
    }

    // Tray
    const pad = S * 0.3;
    const r = S * 0.46;
    const drop = Math.max(4, S * 0.13);
    ctx.fillStyle = INK;
    ctx.beginPath();
    roundRect(ctx, bx - pad, by - pad + drop, bw + pad * 2, bh + pad * 2, r);
    ctx.fill();
    ctx.fillStyle = TRAY;
    ctx.beginPath();
    roundRect(ctx, bx - pad, by - pad, bw + pad * 2, bh + pad * 2, r);
    ctx.fill();
    ctx.lineWidth = Math.max(2.5, S * 0.06);
    ctx.strokeStyle = INK;
    ctx.stroke();

    ctx.translate(bx, by);
    ctx.scale(S, S);

    // Sockets
    ctx.fillStyle = SOCKET;
    ctx.beginPath();
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) roundRect(ctx, x + 0.06, y + 0.06, 0.88, 0.88, 0.2);
    }
    ctx.fill();

    // While paused the pieces are hidden, so pausing can't be used to plan
    // moves with the combo and speed clocks stopped.
    if (this.phase === 'paused') {
      ctx.restore();
      return;
    }

    // Bumpers
    ctx.lineCap = 'round';
    for (let i = 0; i < this.bumpers.length; i++) {
      const kind = this.bumpers[i];
      if (!kind) continue;
      const x = (i % cols) + 0.5;
      const y = Math.floor(i / cols) + 0.5;
      const pulse = this.bumperPulse[i];
      const sc = 1 + 0.45 * Math.sin(pulse * Math.PI);
      const d = 0.25 * sc;
      const sgn = kind === 1 ? -1 : 1;
      ctx.fillStyle = '#EAE2FB';
      ctx.beginPath();
      ctx.arc(x, y, 0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x - d, y - d * sgn);
      ctx.lineTo(x + d, y + d * sgn);
      ctx.strokeStyle = INK;
      ctx.lineWidth = 0.27 * sc;
      ctx.stroke();
      ctx.strokeStyle = pulse > 0.5 ? '#FFFFFF' : BUMPER;
      ctx.lineWidth = 0.17 * sc;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x - d * 0.9 - 0.03, y - d * 0.9 * sgn - 0.035);
      ctx.lineTo(x + d * 0.9 - 0.03, y + d * 0.9 * sgn - 0.035);
      ctx.strokeStyle = BUMPER_LIGHT;
      ctx.lineWidth = 0.045;
      ctx.stroke();
    }

    const cursorId = this.keyboard && !this.locked ? this.occ[this.cursorY * cols + this.cursorX] : -1;

    // Hint halo sits underneath its arrow.
    const hinted = this.hintId >= 0 ? this.byId.get(this.hintId) : undefined;
    if (hinted && hinted.state === IDLE && hinted.spawn >= 1) {
      const p = 0.5 + 0.5 * Math.sin(this.time * 6.5);
      ctx.lineJoin = 'round';
      ctx.strokeStyle = `rgba(255,205,40,${(0.55 + 0.4 * p).toFixed(3)})`;
      ctx.lineWidth = BODY_W + 0.3 + 0.1 * p;
      ctx.stroke(hinted.body);
      ctx.lineWidth = 0.34 + 0.1 * p;
      ctx.stroke(hinted.head);
    }

    // Resting arrows first, moving ones on top.
    for (const a of this.arrows) {
      if (a.state === IDLE) this.drawArrow(ctx, a, a.id === this.hoverId || a.id === cursorId);
    }
    for (const a of this.arrows) {
      if (a.state !== IDLE) this.drawArrow(ctx, a, false);
    }

    if (hinted && hinted.state === IDLE && hinted.spawn >= 1) {
      const h = hinted.cells[hinted.len - 1];
      const q = (this.time * 1.25) % 1;
      ctx.beginPath();
      ctx.arc(h.x + 0.5, h.y + 0.5, 0.28 + 0.5 * q, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(34,28,53,${(0.9 * (1 - q)).toFixed(3)})`;
      ctx.lineWidth = 0.06;
      ctx.stroke();
    }

    // Keyboard cursor: four corner brackets.
    if (this.keyboard && !this.locked) {
      const p = 0.03 * Math.sin(this.time * 7);
      const x0 = this.cursorX + 0.03 - p;
      const y0 = this.cursorY + 0.03 - p;
      const x1 = this.cursorX + 0.97 + p;
      const y1 = this.cursorY + 0.97 + p;
      const L = 0.27;
      const path = new Path2D();
      path.moveTo(x0, y0 + L);
      path.lineTo(x0, y0);
      path.lineTo(x0 + L, y0);
      path.moveTo(x1 - L, y0);
      path.lineTo(x1, y0);
      path.lineTo(x1, y0 + L);
      path.moveTo(x1, y1 - L);
      path.lineTo(x1, y1);
      path.lineTo(x1 - L, y1);
      path.moveTo(x0 + L, y1);
      path.lineTo(x0, y1);
      path.lineTo(x0, y1 - L);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 0.19;
      ctx.stroke(path);
      ctx.strokeStyle = INK;
      ctx.lineWidth = 0.1;
      ctx.stroke(path);
    }

    ctx.restore();
  }

  private drawGates(ctx: CanvasRenderingContext2D) {
    if (!this.gates.length) return;
    const S = this.S;
    ctx.lineCap = 'round';
    for (const g of this.gates) {
      const k = g.age / 0.36;
      const half = S * (0.34 + 0.5 * easeOutCubic(k));
      ctx.globalAlpha = 1 - k;
      ctx.strokeStyle = g.color;
      ctx.lineWidth = Math.max(2, S * 0.2 * (1 - k * 0.6));
      ctx.beginPath();
      if (g.horizontal) {
        ctx.moveTo(g.x - half, g.y);
        ctx.lineTo(g.x + half, g.y);
      } else {
        ctx.moveTo(g.x, g.y - half);
        ctx.lineTo(g.x, g.y + half);
      }
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private drawParticles(ctx: CanvasRenderingContext2D) {
    const ps = this.particles;
    if (!ps.length) return;
    const dpr = this.dpr;
    ctx.lineCap = 'round';
    for (let i = 0; i < ps.length; i++) {
      const p = ps[i];
      const k = p.age / p.life;
      ctx.globalAlpha = k < 0.65 ? 1 : Math.max(0, (1 - k) / 0.35);
      switch (p.kind) {
        case 0: {
          const c = Math.cos(p.rot) * dpr;
          const s = Math.sin(p.rot) * dpr;
          ctx.setTransform(c, s, -s, c, p.x * dpr, p.y * dpr);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size * 0.3, p.size, p.size * 0.6);
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          break;
        }
        case 1:
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, Math.max(0.5, p.size * (1 - k * 0.6)), 0, Math.PI * 2);
          ctx.fill();
          break;
        case 2:
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(1, p.size * (1 - k * 0.5));
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.045, p.y - p.vy * 0.045);
          ctx.stroke();
          break;
        case 3: {
          const e = easeOutCubic(k);
          ctx.globalAlpha = 1 - k;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(1, p.size * 0.16 * (1 - e));
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (0.25 + 0.75 * e), 0, Math.PI * 2);
          ctx.stroke();
          break;
        }
        default: {
          const c = Math.cos(p.rot) * dpr;
          const s = Math.sin(p.rot) * dpr;
          ctx.setTransform(c, s, -s, c, p.x * dpr, p.y * dpr);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.moveTo(0, -p.size * 0.6);
          ctx.lineTo(p.size * 0.55, p.size * 0.45);
          ctx.lineTo(-p.size * 0.5, p.size * 0.35);
          ctx.closePath();
          ctx.fill();
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawPopups(ctx: CanvasRenderingContext2D) {
    if (!this.popups.length) return;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    for (const p of this.popups) {
      const k = p.age / p.life;
      const pop = easeOutBack(clamp01(p.age / 0.2));
      const y = p.y - p.rise * easeOutCubic(k);
      ctx.globalAlpha = k < 0.65 ? 1 : Math.max(0, (1 - k) / 0.35);
      ctx.save();
      ctx.translate(p.x, y);
      ctx.scale(pop, pop);
      ctx.font = `${Math.round(p.size)}px ${FONT}`;
      ctx.lineWidth = Math.max(3, p.size * 0.26);
      ctx.strokeStyle = INK;
      ctx.strokeText(p.text, 0, 0);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, 0, 0);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  private drawDeco(ctx: CanvasRenderingContext2D) {
    for (const d of this.deco) {
      ctx.save();
      ctx.translate(d.x, d.y);
      ctx.scale(d.s, d.s);
      this.paintArrow(ctx, d.body, d.head, d.dir, false, false, null);
      ctx.restore();
    }
  }
}
