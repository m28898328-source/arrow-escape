import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { Hud } from './components/Hud';
import { GameOver, LevelClear, Menu, Pause, ScoresModal } from './components/Overlays';
import { Game } from './game/engine';

export default function App() {
  const [game] = useState(() => new Game());
  const snap = useSyncExternalStore(game.subscribe, game.getSnapshot);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const shakeRef = useRef<HTMLDivElement>(null);
  const slotRef = useRef<HTMLDivElement>(null);

  const [showScores, setShowScores] = useState(false);
  const scoresOpen = useRef(false);
  scoresOpen.current = showScores;

  // Red vignette whenever a heart is lost.
  const [hurt, setHurt] = useState(0);
  const lastHurt = useRef(snap.hurtKey);
  useEffect(() => {
    if (snap.hurtKey !== lastHurt.current) {
      lastHurt.current = snap.hurtKey;
      setHurt(snap.hurtKey);
    }
  }, [snap.hurtKey]);

  // Mount the engine and keep it informed about where the board may sit.
  useEffect(() => {
    const canvas = canvasRef.current;
    const shake = shakeRef.current;
    const slot = slotRef.current;
    if (!canvas || !shake || !slot) return;

    game.attach(canvas, shake);
    // Test builds expose the engine so browser tests can drive it; this branch
    // is statically removed from production bundles.
    if (import.meta.env.MODE === 'test') (window as unknown as { __game?: Game }).__game = game;
    const measure = () => {
      game.resize();
      const c = canvas.getBoundingClientRect();
      const r = slot.getBoundingClientRect();
      game.setBoardArea(r.left - c.left, r.top - c.top, r.width, r.height);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(slot);
    ro.observe(canvas);
    window.addEventListener('resize', measure);
    window.addEventListener('orientationchange', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
      window.removeEventListener('orientationchange', measure);
      game.detach();
    };
  }, [game]);

  // Keyboard: gameplay keys go to the engine, the rest drive the menus.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const target = e.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      game.unlockAudio();

      const key = e.key;
      const lower = key.length === 1 ? key.toLowerCase() : key;
      // A focused button handles Enter/Space itself; don't fire twice.
      const confirm = (key === 'Enter' || key === ' ') && !(target instanceof HTMLButtonElement);
      const phase = game.getSnapshot().phase;

      if (lower === 'm') {
        if (!e.repeat) game.toggleMute();
        return;
      }

      switch (phase) {
        case 'menu':
          if (scoresOpen.current) {
            if (key === 'Escape') setShowScores(false);
          } else if (confirm && !e.repeat) {
            e.preventDefault();
            game.start();
          }
          break;
        case 'playing': {
          if (key === 'Escape' || lower === 'p') {
            e.preventDefault();
            if (!e.repeat) game.pause();
            break;
          }
          const isMove = key.startsWith('Arrow') || 'wasd'.includes(lower);
          // Holding a key may glide the cursor, but never auto-fires launches.
          if (e.repeat && !isMove) {
            if (key === ' ' || key === 'Enter') e.preventDefault();
            break;
          }
          if (game.handleKey(key)) e.preventDefault();
          break;
        }
        case 'paused':
          if (e.repeat) break;
          if (key === 'Escape' || lower === 'p' || confirm) {
            e.preventDefault();
            game.resume();
          } else if (lower === 'r') game.start();
          else if (lower === 'q') game.toMenu();
          break;
        case 'levelclear':
          if (confirm && !e.repeat) {
            e.preventDefault();
            game.nextLevel();
          }
          break;
        case 'gameover':
          if (e.repeat) break;
          if (confirm || lower === 'r') {
            e.preventDefault();
            game.start();
          } else if (key === 'Escape') game.toMenu();
          break;
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [game]);

  // Never let the clock run while the player is looking elsewhere.
  useEffect(() => {
    const onHide = () => {
      if (document.hidden) game.pause();
    };
    const onBlur = () => game.pause();
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('blur', onBlur);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('blur', onBlur);
    };
  }, [game]);

  const inGame = snap.phase !== 'menu';

  return (
    <div className="stage" onPointerDown={() => game.unlockAudio()} onContextMenu={(e) => e.preventDefault()}>
      <div ref={shakeRef} className={`absolute inset-0 will-change-transform ${snap.phase === 'paused' ? 'paused' : ''}`}>
        <canvas ref={canvasRef} aria-label="Arrow Escape game board" />
        <Hud
          snap={snap}
          visible={inGame}
          slotRef={slotRef}
          onHint={() => game.useHint()}
          onPause={() => game.pause()}
          onMute={() => game.toggleMute()}
        />
        {hurt > 0 && inGame && <div key={hurt} className="hurt" onAnimationEnd={() => setHurt(0)} />}
      </div>

      {snap.phase === 'menu' && (
        <Menu
          best={snap.best}
          muted={snap.muted}
          onPlay={() => game.start()}
          onScores={() => setShowScores(true)}
          onMute={() => game.toggleMute()}
        />
      )}
      {snap.phase === 'menu' && showScores && <ScoresModal scores={snap.scores} onClose={() => setShowScores(false)} />}

      {snap.phase === 'paused' && (
        <Pause
          level={snap.level}
          score={snap.score}
          muted={snap.muted}
          onResume={() => game.resume()}
          onRestart={() => game.start()}
          onMenu={() => game.toMenu()}
          onMute={() => game.toggleMute()}
        />
      )}

      {snap.phase === 'levelclear' && snap.result && <LevelClear result={snap.result} onNext={() => game.nextLevel()} />}

      {snap.phase === 'gameover' && snap.final && (
        <GameOver
          final={snap.final}
          scores={snap.scores}
          playerName={snap.playerName}
          onRename={(name) => game.setPlayerName(name)}
          onRestart={() => game.start()}
          onMenu={() => game.toMenu()}
        />
      )}
    </div>
  );
}
