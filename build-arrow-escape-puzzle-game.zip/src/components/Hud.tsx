import type { ReactNode, RefObject } from 'react';
import { COMBO_WINDOW, MAX_HEARTS, type Snapshot, type Tip } from '../game/engine';
import { Heart, Icon, fmt, useCountUp } from './ui';

interface Props {
  snap: Snapshot;
  visible: boolean;
  slotRef: RefObject<HTMLDivElement | null>;
  onHint: () => void;
  onPause: () => void;
  onMute: () => void;
}

const TIP_BADGE: Record<Tip['kind'], { bg: string; fg: string; icon: ReactNode }> = {
  tap: { bg: 'bg-arrow-left', fg: 'text-ink', icon: <Icon name="tap" size={20} /> },
  heart: { bg: 'bg-card', fg: 'text-ink', icon: <Heart size={20} /> },
  bumper: { bg: 'bg-bumper', fg: 'text-white', icon: <Icon name="bumper" size={20} /> },
  frost: { bg: 'bg-ice', fg: 'text-ink', icon: <Icon name="snow" size={20} /> },
  bomb: { bg: 'bg-danger', fg: 'text-white', icon: <Icon name="bomb" size={20} /> },
};

function TipCard({ tip }: { tip: Tip }) {
  const badge = TIP_BADGE[tip.kind];
  return (
    <div className="tip chip mx-auto flex max-w-[min(440px,calc(100%-24px))] items-center gap-2.5 px-2.5 py-1.5">
      <span
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-[2.5px] border-ink ${badge.bg} ${badge.fg}`}
      >
        {badge.icon}
      </span>
      <span className="min-w-0 text-left leading-tight">
        <span className="block font-display text-[15px]">{tip.title}</span>
        <span className="block text-[12.5px] font-medium text-ink-soft">{tip.text}</span>
      </span>
    </div>
  );
}

export function Hud({ snap, visible, slotRef, onHint, onPause, onMute }: Props) {
  const score = useCountUp(snap.score);
  const done = snap.arrowsTotal - snap.arrowsLeft;
  const ratio = snap.arrowsTotal ? done / snap.arrowsTotal : 0;
  const live = visible ? 'pointer-events-auto' : '';

  return (
    <div
      className={`hud safe-area pointer-events-none absolute inset-0 z-10 flex flex-col short:flex-row ${visible ? 'opacity-100' : 'opacity-0'}`}
      aria-hidden={!visible}
    >
      <header className="mx-auto w-full max-w-[560px] px-3 pt-3 short:mx-0 short:w-[176px] short:shrink-0 short:pb-3 short:pr-0">
        <div className="grid grid-cols-[auto_1fr_auto] gap-2 short:grid-cols-1">
          <div className="chip min-w-[68px] px-3 py-1.5">
            <div className="label">Level</div>
            <div key={snap.level} className="score-bump origin-left font-display text-[26px] leading-none">
              {snap.level}
            </div>
          </div>

          <div className="chip min-w-0 px-3 py-1.5 text-center">
            <div className="label">Score</div>
            <div
              key={snap.score}
              className="score-bump font-display text-[clamp(21px,6.4vw,27px)] leading-none tabular-nums"
              aria-live="off"
            >
              {fmt(score)}
            </div>
          </div>

          <div className="chip px-3 py-1.5">
            <div className="label">Lives</div>
            <div className="mt-[1px] flex gap-[3px]" role="img" aria-label={`${snap.hearts} of ${MAX_HEARTS} lives`}>
              {Array.from({ length: MAX_HEARTS }, (_, i) => {
                const filled = i < snap.hearts;
                return <Heart key={`${i}-${filled}`} filled={filled} size={23} className={filled ? 'heart heart-gain' : 'heart heart-lost'} />;
              })}
            </div>
          </div>
        </div>

        <div className="mt-2 flex h-7 items-center gap-2.5 short:mt-3 short:h-auto short:flex-col short:items-stretch short:gap-2">
          <div className="progress flex-1 short:flex-none" role="progressbar" aria-valuemin={0} aria-valuemax={snap.arrowsTotal} aria-valuenow={done}>
            <i style={{ transform: `scaleX(${ratio})` }} />
          </div>
          <div className="flex w-[124px] justify-end short:w-auto short:justify-start">
            {snap.combo >= 2 ? (
              <div key={snap.comboKey} className="combo px-3 pb-[5px] pt-[3px] font-display text-[14px] leading-none">
                COMBO ×{snap.combo}
                <i style={{ animationDuration: `${COMBO_WINDOW}s` }} />
              </div>
            ) : (
              <span className="whitespace-nowrap text-[12px] font-bold uppercase tracking-wider tabular-nums text-ink-soft">
                {snap.arrowsLeft} {snap.arrowsLeft === 1 ? 'arrow' : 'arrows'} left
              </span>
            )}
          </div>
        </div>
      </header>

      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        {snap.tip && (
          <div key={snap.level} className="pt-1.5">
            <TipCard tip={snap.tip} />
          </div>
        )}
        <div ref={slotRef} className="min-h-0 flex-1" />
      </div>

      <footer className="mx-auto flex w-full max-w-[560px] items-center justify-between gap-2 px-3 pb-3 pt-1 short:mx-0 short:w-auto short:shrink-0 short:flex-col-reverse short:justify-center short:gap-3 short:py-3 short:pl-0">
        <button
          type="button"
          tabIndex={-1}
          className={`btn ${live}`}
          disabled={snap.hints <= 0}
          title="Show a safe move (H)"
          aria-label={`Hint, ${snap.hints} left`}
          onClick={(e) => {
            e.currentTarget.blur();
            onHint();
          }}
        >
          <Icon name="bulb" size={20} />
          <span className="short:hidden">Hint</span>
          <span className="flex h-6 min-w-6 items-center justify-center rounded-full bg-ink px-1.5 text-[13px] text-card">
            {snap.hints}
          </span>
        </button>

        <p className="hidden items-center gap-1.5 text-[12px] font-medium text-ink-soft pointer-fine:flex short:hidden!">
          <span className="kbd">←↑↓→</span> move
          <span className="kbd ml-1.5">Space</span> launch
        </p>

        <div className="flex gap-2 short:flex-col short:gap-3">
          <button
            type="button"
            tabIndex={-1}
            className={`btn btn-icon ${live}`}
            title={snap.muted ? 'Sound off (M)' : 'Sound on (M)'}
            aria-label={snap.muted ? 'Unmute sound' : 'Mute sound'}
            onClick={(e) => {
              e.currentTarget.blur();
              onMute();
            }}
          >
            <Icon name={snap.muted ? 'soundOff' : 'soundOn'} />
          </button>
          <button
            type="button"
            tabIndex={-1}
            className={`btn btn-icon ${live}`}
            title="Pause (P)"
            aria-label="Pause"
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
          >
            <Icon name="pause" />
          </button>
        </div>
      </footer>
    </div>
  );
}
